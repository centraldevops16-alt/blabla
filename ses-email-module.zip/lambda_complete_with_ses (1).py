#!/usr/bin/env python3
"""
Complete Lambda Function with SES Integration
DevOps Agent Investigation Trigger with Email Notifications

Author: DevOps Team
Date: 2026-01-28
Version: 1.0.0
"""

import json
import os
import logging
import re
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import boto3

# ============================================================================
# SETUP: Logging & AWS Clients
# ============================================================================

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS Service Clients
sns_client = boto3.client('sns')
ses_client = boto3.client('ses', region_name='us-east-1')
cloudwatch_client = boto3.client('cloudwatch')
devops_agent_client = boto3.client('devopsagent')

# ============================================================================
# ENVIRONMENT VARIABLES
# ============================================================================

AGENT_SPACE_ID = os.environ.get('AGENT_SPACE_ID', '')
SENDER_EMAIL = os.environ.get('SENDER_EMAIL', 'devops-agent@company.com')
RECIPIENT_EMAILS = os.environ.get('RECIPIENT_EMAILS', 'team@company.com')
SLACK_CHANNEL = os.environ.get('SLACK_CHANNEL', '')
SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN', '')

# Validate required environment variables
if not AGENT_SPACE_ID:
    logger.warning("⚠️ AGENT_SPACE_ID not set. DevOps Agent investigations will be skipped.")

# ============================================================================
# SECTION 1: CloudWatch Alarm Parsing
# ============================================================================

def parse_cloudwatch_alarm(sns_message):
    """
    Parse CloudWatch alarm from SNS message.
    
    Args:
        sns_message (dict): SNS message containing CloudWatch alarm
        
    Returns:
        dict: Parsed alarm data with all relevant fields
    """
    try:
        # Parse SNS message JSON
        if isinstance(sns_message, str):
            alarm_data = json.loads(sns_message)
        else:
            alarm_data = sns_message
        
        # Extract key fields
        alarm = {
            'alarm_name': alarm_data.get('AlarmName', 'Unknown Alarm'),
            'alarm_description': alarm_data.get('AlarmDescription', 'No description'),
            'alarm_state_reason': alarm_data.get('StateChangeReason', 'State changed'),
            'state_updated_timestamp': alarm_data.get('StateUpdatedTimestamp', datetime.utcnow().isoformat()),
            'alarm_arn': alarm_data.get('AlarmsArn', 'N/A'),
            'region': alarm_data.get('Region', 'us-east-1'),
            'namespace': alarm_data.get('Trigger', {}).get('Namespace', 'AWS/EC2'),
            'metric_name': alarm_data.get('Trigger', {}).get('MetricName', 'Unknown'),
            'statistic': alarm_data.get('Trigger', {}).get('Statistic', 'Average'),
            'threshold': alarm_data.get('Trigger', {}).get('Threshold', 'N/A'),
            'comparison_operator': alarm_data.get('Trigger', {}).get('ComparisonOperator', 'GreaterThanThreshold'),
            'evaluation_periods': alarm_data.get('Trigger', {}).get('EvaluationPeriods', '1'),
            'period': alarm_data.get('Trigger', {}).get('Period', '300'),
            'trigger': alarm_data.get('Trigger', {}),
            'raw_data': alarm_data,
        }
        
        logger.info(f"✅ Parsed alarm: {alarm['alarm_name']} in {alarm['region']}")
        return alarm
    
    except Exception as e:
        logger.error(f"❌ Error parsing CloudWatch alarm: {str(e)}")
        raise


def extract_account_id_from_arn(arn):
    """Extract AWS account ID from ARN."""
    try:
        # ARN format: arn:aws:service:region:account-id:resource
        parts = arn.split(':')
        if len(parts) >= 5:
            return parts[4]
    except Exception as e:
        logger.warning(f"Could not extract account ID from ARN: {str(e)}")
    return 'Unknown'

# ============================================================================
# SECTION 2: DevOps Agent Investigation
# ============================================================================

def start_investigation(alarm_data):
    """
    Start a DevOps Agent investigation for the alarm.
    
    Args:
        alarm_data (dict): Parsed alarm data
        
    Returns:
        dict: Investigation response with ID and status
    """
    if not AGENT_SPACE_ID:
        logger.warning("⚠️ AGENT_SPACE_ID not configured. Skipping investigation.")
        return {
            'investigation_id': 'N/A',
            'status': 'SKIPPED',
            'reason': 'Agent Space ID not configured'
        }
    
    try:
        # Prepare investigation request
        investigation_request = {
            'spaceId': AGENT_SPACE_ID,
            'description': f"Automatic investigation for alarm: {alarm_data['alarm_name']}",
            'alarmMetadata': {
                'alarmName': alarm_data['alarm_name'],
                'alarmArn': alarm_data['alarm_arn'],
                'metricName': alarm_data['metric_name'],
                'namespace': alarm_data['namespace'],
                'statistic': alarm_data['statistic'],
                'threshold': str(alarm_data['threshold']),
            }
        }
        
        # Call DevOps Agent API
        response = devops_agent_client.create_investigation(**investigation_request)
        
        investigation_id = response.get('investigationId', 'Unknown')
        status = response.get('status', 'CREATED')
        
        logger.info(f"✅ Investigation created: {investigation_id} ({status})")
        
        return {
            'investigation_id': investigation_id,
            'status': status,
            'response': response
        }
    
    except Exception as e:
        logger.error(f"❌ Error starting investigation: {str(e)}")
        return {
            'investigation_id': None,
            'status': 'ERROR',
            'error': str(e)
        }

# ============================================================================
# SECTION 3: Email Generation - HTML
# ============================================================================

def create_investigation_html_email(alarm_data, investigation_response):
    """
    Create rich HTML email for investigation notification.
    
    Args:
        alarm_data (dict): Parsed alarm data
        investigation_response (dict): Investigation response from DevOps Agent
        
    Returns:
        str: HTML email content
    """
    
    investigation_id = investigation_response.get('investigation_id', 'N/A')
    investigation_link = f"https://console.aws.amazon.com/devopsagent/investigation/{investigation_id}" if investigation_id != 'N/A' else '#'
    account_id = extract_account_id_from_arn(alarm_data.get('alarm_arn', ''))
    
    html_content = f"""
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {{
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                line-height: 1.6;
                color: #333;
                background: #f5f5f5;
                margin: 0;
                padding: 0;
            }}
            .container {{
                max-width: 600px;
                margin: 20px auto;
                background: white;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                overflow: hidden;
            }}
            .header {{
                background: linear-gradient(135deg, #FF9900 0%, #FF6600 100%);
                color: white;
                padding: 30px 20px;
                text-align: center;
            }}
            .header h1 {{
                margin: 0;
                font-size: 28px;
                font-weight: bold;
            }}
            .header .aws-badge {{
                display: inline-block;
                background: rgba(0,0,0,0.2);
                padding: 6px 12px;
                border-radius: 4px;
                font-size: 12px;
                margin-top: 10px;
            }}
            .alert-status {{
                padding: 20px;
                background: #fff3cd;
                border-left: 4px solid #ffc107;
                margin: 0;
            }}
            .alert-status h2 {{
                margin: 0 0 10px 0;
                color: #856404;
                font-size: 16px;
            }}
            .section {{
                padding: 20px;
                border-bottom: 1px solid #eee;
            }}
            .section:last-child {{
                border-bottom: none;
            }}
            .section-title {{
                font-size: 14px;
                font-weight: bold;
                color: #FF6600;
                text-transform: uppercase;
                margin-bottom: 12px;
            }}
            .detail-row {{
                display: flex;
                justify-content: space-between;
                margin: 8px 0;
                font-size: 14px;
            }}
            .detail-label {{
                font-weight: 600;
                color: #555;
                min-width: 140px;
            }}
            .detail-value {{
                color: #333;
                flex-grow: 1;
                text-align: right;
            }}
            .metric-box {{
                background: #f0f0f0;
                border-left: 3px solid #FF6600;
                padding: 12px;
                margin: 10px 0;
                border-radius: 4px;
            }}
            .investigation-link {{
                display: inline-block;
                background: #FF6600;
                color: white;
                padding: 12px 20px;
                text-decoration: none;
                border-radius: 4px;
                font-weight: bold;
                margin: 10px 0;
            }}
            .investigation-link:hover {{
                background: #ff5500;
            }}
            .next-steps {{
                background: #e7f3ff;
                border-left: 3px solid #0066cc;
                padding: 12px;
                margin: 15px 0;
                border-radius: 4px;
            }}
            .next-steps h4 {{
                margin: 0 0 10px 0;
                color: #0066cc;
            }}
            .next-steps ul {{
                margin: 0;
                padding-left: 20px;
            }}
            .next-steps li {{
                margin: 5px 0;
                font-size: 13px;
            }}
            .footer {{
                padding: 15px;
                background: #f9f9f9;
                text-align: center;
                font-size: 12px;
                color: #666;
            }}
            .footer a {{
                color: #FF6600;
                text-decoration: none;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <!-- Header -->
            <div class="header">
                <h1>🚨 DevOps Investigation Alert</h1>
                <div class="aws-badge">AWS CloudWatch Alarm</div>
            </div>
            
            <!-- Alert Status -->
            <div class="alert-status">
                <h2>⚠️ Alarm Triggered: {alarm_data['alarm_name']}</h2>
                <p>{alarm_data['alarm_state_reason']}</p>
            </div>
            
            <!-- Alarm Details -->
            <div class="section">
                <div class="section-title">Alarm Information</div>
                <div class="detail-row">
                    <div class="detail-label">Alarm Name:</div>
                    <div class="detail-value"><strong>{alarm_data['alarm_name']}</strong></div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">Status:</div>
                    <div class="detail-value">🔴 ALARM</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">Triggered:</div>
                    <div class="detail-value">{alarm_data['state_updated_timestamp']}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">Region:</div>
                    <div class="detail-value">{alarm_data['region']}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">AWS Account:</div>
                    <div class="detail-value">{account_id}</div>
                </div>
            </div>
            
            <!-- Metric Details -->
            <div class="section">
                <div class="section-title">Metric Details</div>
                <div class="metric-box">
                    <div class="detail-row">
                        <div class="detail-label">Metric:</div>
                        <div class="detail-value"><strong>{alarm_data['metric_name']}</strong></div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Namespace:</div>
                        <div class="detail-value">{alarm_data['namespace']}</div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Statistic:</div>
                        <div class="detail-value">{alarm_data['statistic']}</div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Threshold:</div>
                        <div class="detail-value">{alarm_data['threshold']} ({alarm_data['comparison_operator']})</div>
                    </div>
                </div>
            </div>
            
            <!-- Investigation -->
            <div class="section">
                <div class="section-title">Automatic Investigation</div>
                <p><strong>Investigation ID:</strong> {investigation_id}</p>
                <p><strong>Status:</strong> {investigation_response.get('status', 'PENDING')}</p>
                
                {f'<a href="{investigation_link}" class="investigation-link">View Investigation Results →</a>' if investigation_id != 'N/A' else ''}
                
                <div class="next-steps">
                    <h4>✅ What DevOps Agent Analyzes:</h4>
                    <ul>
                        <li>Last 24 hours of CloudWatch metrics and trends</li>
                        <li>Recent CloudTrail events (API calls)</li>
                        <li>Application logs and error patterns</li>
                        <li>Recent deployments and changes</li>
                        <li>Performance anomalies</li>
                        <li>Identifies potential root causes</li>
                    </ul>
                </div>
            </div>
            
            <!-- Useful Links -->
            <div class="section">
                <div class="section-title">Useful Links</div>
                <ul style="margin: 0; padding-left: 20px;">
                    <li><a href="https://console.aws.amazon.com/cloudwatch/home?region={alarm_data['region']}#alarmsV2:alarmFilter={alarm_data['alarm_name']}" style="color: #FF6600; text-decoration: none;">View in CloudWatch</a></li>
                    <li><a href="https://console.aws.amazon.com/devopsagent/" style="color: #FF6600; text-decoration: none;">DevOps Agent Console</a></li>
                    <li><a href="https://docs.aws.amazon.com/devopsagent/" style="color: #FF6600; text-decoration: none;">DevOps Agent Documentation</a></li>
                </ul>
            </div>
            
            <!-- Footer -->
            <div class="footer">
                <p>This is an automated alert from AWS DevOps Agent Investigation System.</p>
                <p><a href="https://aws.amazon.com/devopsagent/">Learn more about AWS DevOps Agent</a></p>
                <p style="margin-top: 15px; border-top: 1px solid #ddd; padding-top: 15px;">
                    © 2026 Your Company. All rights reserved.
                </p>
            </div>
        </div>
    </body>
    </html>
    """
    
    return html_content

# ============================================================================
# SECTION 4: Email Generation - Plain Text
# ============================================================================

def create_plain_text_email(alarm_data, investigation_response):
    """
    Create plain text email for email clients that don't support HTML.
    
    Args:
        alarm_data (dict): Parsed alarm data
        investigation_response (dict): Investigation response
        
    Returns:
        str: Plain text email content
    """
    
    investigation_id = investigation_response.get('investigation_id', 'N/A')
    account_id = extract_account_id_from_arn(alarm_data.get('alarm_arn', ''))
    
    text_content = f"""
AWS DevOps Investigation Alert
================================

🚨 ALARM TRIGGERED: {alarm_data['alarm_name']}

Status: ALARM
Triggered: {alarm_data['state_updated_timestamp']}
Region: {alarm_data['region']}
AWS Account: {account_id}

ALARM DETAILS
=============
Name: {alarm_data['alarm_name']}
Description: {alarm_data['alarm_description']}
Reason: {alarm_data['alarm_state_reason']}

METRIC INFORMATION
==================
Metric Name: {alarm_data['metric_name']}
Namespace: {alarm_data['namespace']}
Statistic: {alarm_data['statistic']}
Threshold: {alarm_data['threshold']} ({alarm_data['comparison_operator']})
Evaluation Periods: {alarm_data['evaluation_periods']}
Period: {alarm_data['period']} seconds

AUTOMATIC INVESTIGATION
=======================
Investigation ID: {investigation_id}
Status: {investigation_response.get('status', 'PENDING')}

The DevOps Agent is automatically analyzing:
✓ Last 24 hours of CloudWatch metrics
✓ Recent API calls (CloudTrail)
✓ Application logs and errors
✓ Recent deployments and changes
✓ Performance anomalies
✓ Potential root causes

View full investigation results in the AWS DevOps Agent Console:
https://console.aws.amazon.com/devopsagent/

USEFUL LINKS
============
CloudWatch Alarm: https://console.aws.amazon.com/cloudwatch/home?region={alarm_data['region']}
DevOps Agent Console: https://console.aws.amazon.com/devopsagent/
AWS Documentation: https://docs.aws.amazon.com/devopsagent/

---
This is an automated alert from AWS DevOps Agent Investigation System.
© 2026 Your Company. All rights reserved.
    """
    
    return text_content

# ============================================================================
# SECTION 5: SES Email Sending
# ============================================================================

def send_investigation_email(alarm_data, investigation_response, recipients=None):
    """
    Send investigation notification email via SES.
    
    Args:
        alarm_data (dict): Parsed alarm data
        investigation_response (dict): Investigation response
        recipients (list): List of recipient emails (optional, uses env var if not provided)
        
    Returns:
        dict: SES send response with MessageId
    """
    
    if recipients is None:
        recipients = [r.strip() for r in RECIPIENT_EMAILS.split(',')]
    
    try:
        # Validate recipients
        if not recipients or not all(recipients):
            logger.error("❌ No valid recipients specified")
            return {'status': 'ERROR', 'message': 'No recipients'}
        
        # Create MIME message
        message = MIMEMultipart('alternative')
        message['Subject'] = f"[DevOps Investigation] {alarm_data['alarm_name']}"
        message['From'] = SENDER_EMAIL
        message['To'] = ', '.join(recipients)
        
        # Generate email content
        plain_text = create_plain_text_email(alarm_data, investigation_response)
        html_content = create_investigation_html_email(alarm_data, investigation_response)
        
        # Attach both versions
        message.attach(MIMEText(plain_text, 'plain'))
        message.attach(MIMEText(html_content, 'html'))
        
        # Send via SES
        response = ses_client.send_raw_email(
            Source=SENDER_EMAIL,
            Destinations=recipients,
            RawMessage={'Data': message.as_string()}
        )
        
        message_id = response.get('MessageId', 'Unknown')
        logger.info(f"✅ Email sent successfully (MessageId: {message_id}) to {recipients}")
        
        return {
            'status': 'SUCCESS',
            'message_id': message_id,
            'recipients': recipients,
            'response': response
        }
    
    except ses_client.exceptions.MessageRejected as e:
        logger.error(f"❌ SES rejected message: {str(e)}")
        return {
            'status': 'ERROR',
            'error_type': 'MessageRejected',
            'error': str(e),
            'message': 'Email address not verified or account paused'
        }
    
    except ses_client.exceptions.ConfigurationSetDoesNotExistException as e:
        logger.error(f"❌ Configuration set error: {str(e)}")
        return {
            'status': 'ERROR',
            'error_type': 'ConfigurationSetError',
            'error': str(e)
        }
    
    except Exception as e:
        logger.error(f"❌ Error sending email: {str(e)}")
        return {
            'status': 'ERROR',
            'error_type': type(e).__name__,
            'error': str(e)
        }

# ============================================================================
# SECTION 6: Slack Notifications (Optional)
# ============================================================================

def send_slack_notification(alarm_data, investigation_response):
    """
    Send investigation notification to Slack (optional).
    
    Args:
        alarm_data (dict): Parsed alarm data
        investigation_response (dict): Investigation response
        
    Returns:
        dict: SNS publish response
    """
    
    if not SLACK_CHANNEL or not SNS_TOPIC_ARN:
        logger.info("⚠️ Slack notification skipped (not configured)")
        return {'status': 'SKIPPED', 'reason': 'Slack not configured'}
    
    try:
        slack_message = {
            'channel': SLACK_CHANNEL,
            'username': 'AWS DevOps Agent',
            'icon_emoji': ':warning:',
            'attachments': [
                {
                    'fallback': f"Alarm: {alarm_data['alarm_name']}",
                    'color': 'danger',
                    'title': f"🚨 {alarm_data['alarm_name']}",
                    'text': alarm_data['alarm_state_reason'],
                    'fields': [
                        {
                            'title': 'Metric',
                            'value': alarm_data['metric_name'],
                            'short': True
                        },
                        {
                            'title': 'Threshold',
                            'value': f"{alarm_data['threshold']} ({alarm_data['comparison_operator']})",
                            'short': True
                        },
                        {
                            'title': 'Investigation ID',
                            'value': investigation_response.get('investigation_id', 'N/A'),
                            'short': False
                        },
                        {
                            'title': 'Region',
                            'value': alarm_data['region'],
                            'short': True
                        },
                        {
                            'title': 'Status',
                            'value': investigation_response.get('status', 'PENDING'),
                            'short': True
                        }
                    ],
                    'ts': int(datetime.utcnow().timestamp())
                }
            ]
        }
        
        response = sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=json.dumps(slack_message),
            Subject=f"DevOps Agent: {alarm_data['alarm_name']}"
        )
        
        logger.info(f"✅ Slack notification sent (MessageId: {response['MessageId']})")
        return {
            'status': 'SUCCESS',
            'message_id': response['MessageId']
        }
    
    except Exception as e:
        logger.error(f"❌ Error sending Slack notification: {str(e)}")
        return {
            'status': 'ERROR',
            'error': str(e)
        }

# ============================================================================
# SECTION 7: Logging & Monitoring
# ============================================================================

def log_investigation(alarm_data, investigation_response, email_response):
    """
    Log investigation details to CloudWatch for audit trail.
    
    Args:
        alarm_data (dict): Parsed alarm data
        investigation_response (dict): Investigation response
        email_response (dict): Email send response
    """
    
    log_entry = {
        'timestamp': datetime.utcnow().isoformat(),
        'alarm_name': alarm_data.get('alarm_name'),
        'alarm_arn': alarm_data.get('alarm_arn'),
        'metric_name': alarm_data.get('metric_name'),
        'investigation_id': investigation_response.get('investigation_id'),
        'investigation_status': investigation_response.get('status'),
        'email_status': email_response.get('status'),
        'email_message_id': email_response.get('message_id'),
        'recipients': email_response.get('recipients', []),
        'region': alarm_data.get('region'),
    }
    
    logger.info(f"📊 Investigation Log: {json.dumps(log_entry, indent=2)}")
    
    return log_entry

# ============================================================================
# SECTION 8: MAIN Lambda Handler
# ============================================================================

def lambda_handler(event, context):
    """
    Main Lambda handler for CloudWatch alarm events via SNS.
    
    Args:
        event (dict): SNS event containing CloudWatch alarm
        context (object): Lambda context
        
    Returns:
        dict: Response with status and details
    """
    
    logger.info(f"🚀 Lambda invoked at {datetime.utcnow().isoformat()}")
    logger.info(f"Event: {json.dumps(event, indent=2)}")
    
    try:
        # Extract SNS message
        if 'Records' not in event or len(event['Records']) == 0:
            logger.error("❌ No SNS records found in event")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Invalid event structure'})
            }
        
        sns_record = event['Records'][0]
        sns_message = sns_record.get('Sns', {}).get('Message', '')
        
        if not sns_message:
            logger.error("❌ No SNS message found")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'No SNS message'})
            }
        
        # Parse CloudWatch alarm
        logger.info("📋 Parsing CloudWatch alarm...")
        alarm_data = parse_cloudwatch_alarm(sns_message)
        
        # Skip non-ALARM state
        if alarm_data['raw_data'].get('NewStateValue') != 'ALARM':
            logger.info(f"ℹ️ Skipping non-ALARM state: {alarm_data['raw_data'].get('NewStateValue')}")
            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Skipped non-ALARM event'})
            }
        
        # Start investigation
        logger.info("🔍 Starting DevOps Agent investigation...")
        investigation_response = start_investigation(alarm_data)
        
        # Send email notification
        logger.info("📧 Sending email notification...")
        email_response = send_investigation_email(alarm_data, investigation_response)
        
        # Send Slack notification (optional)
        if SLACK_CHANNEL and SNS_TOPIC_ARN:
            logger.info("💬 Sending Slack notification...")
            slack_response = send_slack_notification(alarm_data, investigation_response)
        else:
            slack_response = {'status': 'SKIPPED'}
        
        # Log investigation
        logger.info("📝 Logging investigation details...")
        log_entry = log_investigation(alarm_data, investigation_response, email_response)
        
        # Build response
        success = email_response.get('status') == 'SUCCESS'
        
        response = {
            'statusCode': 200 if success else 500,
            'body': json.dumps({
                'message': 'Investigation initiated and notification sent' if success else 'Investigation initiated but notification failed',
                'alarm_name': alarm_data['alarm_name'],
                'investigation_id': investigation_response.get('investigation_id'),
                'investigation_status': investigation_response.get('status'),
                'email_status': email_response.get('status'),
                'email_message_id': email_response.get('message_id'),
                'slack_status': slack_response.get('status'),
                'log_entry': log_entry
            })
        }
        
        logger.info(f"✅ Lambda completed successfully: {json.dumps(response, indent=2)}")
        return response
    
    except Exception as e:
        logger.error(f"❌ Lambda execution failed: {str(e)}", exc_info=True)
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'message': 'Lambda execution failed'
            })
        }

# ============================================================================
# END OF FILE
# ============================================================================
