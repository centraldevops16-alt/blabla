"""
AWS SES Email Integration Module for DevOps Agent Investigation Lambda

Sends rich HTML emails with investigation analysis summaries
"""

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import boto3
import os
from typing import Dict, Any, List
from datetime import datetime

ses_client = boto3.client('ses', region_name='us-east-1')

# SES Configuration
SENDER_EMAIL = os.environ.get('SENDER_EMAIL', 'devops-agent@yourdomain.com')
RECIPIENT_EMAILS = os.environ.get('RECIPIENT_EMAILS', '').split(',')


def create_investigation_html_email(alarm_data: Dict[str, Any], investigation_response: Dict[str, Any]) -> str:
    """
    Create rich HTML email with investigation analysis
    """
    investigation_id = investigation_response.get('investigationId', 'Unknown')
    console_url = f"https://us-east-1.console.aws.amazon.com/cloudwatch/home?region=us-east-1#alarmsV2:alarmFilter={alarm_data['alarm_name']}"
    
    html_body = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
            }}
            .container {{
                max-width: 800px;
                margin: 20px auto;
                background-color: #ffffff;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                overflow: hidden;
            }}
            .header {{
                background: linear-gradient(135deg, #FF9900 0%, #FF6B35 100%);
                color: white;
                padding: 30px;
                text-align: center;
            }}
            .header h1 {{
                margin: 0;
                font-size: 24px;
                font-weight: 600;
            }}
            .status-badge {{
                display: inline-block;
                background-color: rgba(255,255,255,0.3);
                padding: 8px 16px;
                border-radius: 4px;
                margin-top: 10px;
                font-size: 14px;
            }}
            .content {{
                padding: 30px;
            }}
            .section {{
                margin-bottom: 25px;
                padding-bottom: 20px;
                border-bottom: 1px solid #e0e0e0;
            }}
            .section:last-child {{
                border-bottom: none;
                margin-bottom: 0;
                padding-bottom: 0;
            }}
            .section-title {{
                font-size: 16px;
                font-weight: 600;
                color: #232f3e;
                margin-bottom: 12px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }}
            .detail-row {{
                display: flex;
                padding: 8px 0;
                border-bottom: 1px solid #f0f0f0;
            }}
            .detail-row:last-child {{
                border-bottom: none;
            }}
            .detail-label {{
                font-weight: 600;
                color: #555;
                width: 180px;
                flex-shrink: 0;
            }}
            .detail-value {{
                color: #232f3e;
                word-break: break-word;
                flex: 1;
            }}
            .alert-box {{
                background-color: #fff3cd;
                border-left: 4px solid #ffc107;
                padding: 15px;
                margin: 15px 0;
                border-radius: 4px;
            }}
            .alert-title {{
                font-weight: 600;
                color: #856404;
                margin-bottom: 8px;
            }}
            .alert-content {{
                color: #856404;
                font-size: 13px;
                line-height: 1.6;
            }}
            .metric-box {{
                background-color: #f8f9fa;
                border: 1px solid #e9ecef;
                padding: 15px;
                border-radius: 4px;
                margin: 10px 0;
            }}
            .metric-value {{
                font-size: 18px;
                font-weight: 700;
                color: #FF9900;
            }}
            .metric-label {{
                font-size: 12px;
                color: #666;
                text-transform: uppercase;
            }}
            .cta-button {{
                display: inline-block;
                background-color: #FF9900;
                color: white;
                padding: 12px 24px;
                text-decoration: none;
                border-radius: 4px;
                margin-top: 15px;
                font-weight: 600;
                font-size: 14px;
            }}
            .cta-button:hover {{
                background-color: #FF6B35;
            }}
            .footer {{
                background-color: #f5f5f5;
                padding: 20px;
                text-align: center;
                border-top: 1px solid #e0e0e0;
                font-size: 12px;
                color: #666;
            }}
            .timestamp {{
                color: #999;
                font-size: 12px;
                margin-top: 10px;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🚨 DevOps Agent Investigation Triggered</h1>
                <div class="status-badge">Automatic Analysis in Progress</div>
            </div>
            
            <div class="content">
                <!-- Alert Section -->
                <div class="section">
                    <div class="section-title">Alarm Triggered</div>
                    <div class="detail-row">
                        <span class="detail-label">Alarm Name:</span>
                        <span class="detail-value"><strong>{alarm_data['alarm_name']}</strong></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status:</span>
                        <span class="detail-value"><strong>{alarm_data['state']}</strong></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Time:</span>
                        <span class="detail-value">{alarm_data['timestamp']}</span>
                    </div>
                </div>
                
                <!-- Alert Details -->
                <div class="alert-box">
                    <div class="alert-title">Reason for Alert</div>
                    <div class="alert-content">{alarm_data['state_reason']}</div>
                </div>
                
                <!-- Investigation Details -->
                <div class="section">
                    <div class="section-title">Investigation Details</div>
                    <div class="detail-row">
                        <span class="detail-label">Investigation ID:</span>
                        <span class="detail-value"><code>{investigation_id}</code></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">AWS Account:</span>
                        <span class="detail-value">{alarm_data['account_id']}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Region:</span>
                        <span class="detail-value">{alarm_data['region']}</span>
                    </div>
                </div>
                
                <!-- Metric Information -->
                <div class="section">
                    <div class="section-title">Metric Information</div>
                    <div class="metric-box">
                        <div class="metric-label">Metric Name</div>
                        <div class="metric-value">{alarm_data['trigger'].get('MetricName', 'N/A')}</div>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Namespace:</span>
                        <span class="detail-value">{alarm_data['trigger'].get('Namespace', 'N/A')}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Threshold:</span>
                        <span class="detail-value">{alarm_data['trigger'].get('Threshold', 'N/A')}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Statistic:</span>
                        <span class="detail-value">{alarm_data['trigger'].get('Statistic', 'N/A')}</span>
                    </div>
                </div>
                
                <!-- Next Steps -->
                <div class="section">
                    <div class="section-title">What Happens Next</div>
                    <p style="color: #666; line-height: 1.6;">
                        AWS DevOps Agent is now automatically investigating this alarm. It will:
                    </p>
                    <ul style="color: #666; line-height: 1.8;">
                        <li>Analyze CloudWatch metrics from the past 24 hours</li>
                        <li>Review CloudTrail events for recent changes (90 days)</li>
                        <li>Examine application logs and traces</li>
                        <li>Identify recently deployed code changes</li>
                        <li>Generate a root cause hypothesis</li>
                        <li>Provide remediation recommendations</li>
                    </ul>
                    
                    <a href="https://us-east-1.console.aws.amazon.com/devopsagent" class="cta-button">
                        📊 View Investigation Results
                    </a>
                </div>
                
                <!-- Resources -->
                <div class="section">
                    <div class="section-title">Useful Links</div>
                    <div class="detail-row" style="border-bottom: none;">
                        <a href="{console_url}" style="color: #FF9900; text-decoration: none; font-weight: 500;">
                            → View CloudWatch Alarm
                        </a>
                    </div>
                    <div class="detail-row" style="border-bottom: none;">
                        <a href="https://docs.aws.amazon.com/devopsagent/" style="color: #FF9900; text-decoration: none; font-weight: 500;">
                            → DevOps Agent Documentation
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="footer">
                <p>This email was automatically sent by AWS DevOps Agent</p>
                <div class="timestamp">
                    Investigation ID: {investigation_id}<br>
                    Sent: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}
                </div>
            </div>
        </div>
    </body>
    </html>
    """
    return html_body


def create_plain_text_email(alarm_data: Dict[str, Any], investigation_response: Dict[str, Any]) -> str:
    """
    Create plain text version of investigation email
    """
    investigation_id = investigation_response.get('investigationId', 'Unknown')
    
    text_body = f"""
DevOps Agent Investigation Triggered
=====================================

ALARM TRIGGERED
---------------
Alarm Name: {alarm_data['alarm_name']}
Status: {alarm_data['state']}
Time: {alarm_data['timestamp']}

REASON FOR ALERT
----------------
{alarm_data['state_reason']}

INVESTIGATION DETAILS
---------------------
Investigation ID: {investigation_id}
AWS Account: {alarm_data['account_id']}
Region: {alarm_data['region']}

METRIC INFORMATION
------------------
Metric Name: {alarm_data['trigger'].get('MetricName', 'N/A')}
Namespace: {alarm_data['trigger'].get('Namespace', 'N/A')}
Threshold: {alarm_data['trigger'].get('Threshold', 'N/A')}
Statistic: {alarm_data['trigger'].get('Statistic', 'N/A')}

WHAT HAPPENS NEXT
-----------------
AWS DevOps Agent is now automatically investigating this alarm. It will:
- Analyze CloudWatch metrics from the past 24 hours
- Review CloudTrail events for recent changes (90 days)
- Examine application logs and traces
- Identify recently deployed code changes
- Generate a root cause hypothesis
- Provide remediation recommendations

VIEW RESULTS
-----------
Console: https://us-east-1.console.aws.amazon.com/devopsagent

---
This email was automatically sent by AWS DevOps Agent
Timestamp: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}
Investigation ID: {investigation_id}
    """
    return text_body.strip()


def send_investigation_email(
    alarm_data: Dict[str, Any],
    investigation_response: Dict[str, Any],
    recipients: List[str] = None
) -> Dict[str, Any]:
    """
    Send investigation email via AWS SES
    
    Args:
        alarm_data: Parsed CloudWatch alarm data
        investigation_response: DevOps Agent investigation response
        recipients: List of email recipients (optional, uses RECIPIENT_EMAILS env var if not provided)
        
    Returns:
        SES send_raw_email response
    """
    
    if not recipients:
        recipients = RECIPIENT_EMAILS
    
    # Filter out empty strings
    recipients = [r.strip() for r in recipients if r.strip()]
    
    if not recipients:
        print("No recipient emails configured. Skipping email send.")
        return {'statusCode': 204, 'message': 'No recipients configured'}
    
    if not SENDER_EMAIL or SENDER_EMAIL == 'devops-agent@yourdomain.com':
        print("SENDER_EMAIL not properly configured in environment variables")
        return {'statusCode': 400, 'message': 'Sender email not configured'}
    
    try:
        # Create MIME message
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f"[DevOps Investigation] {alarm_data['alarm_name']}"
        msg['From'] = SENDER_EMAIL
        msg['To'] = ', '.join(recipients)
        
        # Create plain text and HTML versions
        text_part = MIMEText(
            create_plain_text_email(alarm_data, investigation_response),
            'plain'
        )
        html_part = MIMEText(
            create_investigation_html_email(alarm_data, investigation_response),
            'html'
        )
        
        # Attach both versions (plain text first, then HTML - client will prefer HTML)
        msg.attach(text_part)
        msg.attach(html_part)
        
        # Send via SES
        response = ses_client.send_raw_email(
            Source=SENDER_EMAIL,
            Destinations=recipients,
            RawMessage={'Data': msg.as_string()}
        )
        
        print(f"Email sent successfully. Message ID: {response.get('MessageId')}")
        return {
            'statusCode': 200,
            'message': 'Email sent successfully',
            'message_id': response.get('MessageId'),
            'recipients': recipients
        }
        
    except ses_client.exceptions.MessageRejected as e:
        error_msg = f"SES rejected message: {str(e)}"
        print(error_msg)
        return {'statusCode': 400, 'error': error_msg}
    
    except ses_client.exceptions.ConfigurationSetDoesNotExistException as e:
        error_msg = f"Configuration set does not exist: {str(e)}"
        print(error_msg)
        return {'statusCode': 400, 'error': error_msg}
    
    except ses_client.exceptions.AccountSendingPausedException as e:
        error_msg = f"Account sending is paused: {str(e)}"
        print(error_msg)
        return {'statusCode': 400, 'error': error_msg}
    
    except Exception as e:
        error_msg = f"Error sending email via SES: {str(e)}"
        print(error_msg)
        return {'statusCode': 500, 'error': error_msg}


def send_investigation_email_with_attachment(
    alarm_data: Dict[str, Any],
    investigation_response: Dict[str, Any],
    attachment_file_path: str = None,
    attachment_filename: str = None,
    recipients: List[str] = None
) -> Dict[str, Any]:
    """
    Send investigation email with attachment (e.g., analysis report PDF)
    
    Args:
        alarm_data: Parsed CloudWatch alarm data
        investigation_response: DevOps Agent investigation response
        attachment_file_path: Path to file to attach
        attachment_filename: Display name for attachment
        recipients: List of email recipients
        
    Returns:
        SES send_raw_email response
    """
    
    if not recipients:
        recipients = RECIPIENT_EMAILS
    
    recipients = [r.strip() for r in recipients if r.strip()]
    
    if not recipients:
        print("No recipient emails configured")
        return {'statusCode': 204, 'message': 'No recipients configured'}
    
    try:
        # Create MIME message
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f"[DevOps Investigation] {alarm_data['alarm_name']}"
        msg['From'] = SENDER_EMAIL
        msg['To'] = ', '.join(recipients)
        
        # Attach body text
        text_part = MIMEText(
            create_plain_text_email(alarm_data, investigation_response),
            'plain'
        )
        html_part = MIMEText(
            create_investigation_html_email(alarm_data, investigation_response),
            'html'
        )
        msg.attach(text_part)
        msg.attach(html_part)
        
        # Attach file if provided
        if attachment_file_path and os.path.exists(attachment_file_path):
            try:
                with open(attachment_file_path, 'rb') as f:
                    part = MIMEApplication(f.read())
                    part.add_header(
                        'Content-Disposition',
                        'attachment',
                        filename=attachment_filename or os.path.basename(attachment_file_path)
                    )
                    msg.attach(part)
                    print(f"Attached file: {attachment_filename}")
            except Exception as e:
                print(f"Warning: Could not attach file: {str(e)}")
        
        # Send via SES
        response = ses_client.send_raw_email(
            Source=SENDER_EMAIL,
            Destinations=recipients,
            RawMessage={'Data': msg.as_string()}
        )
        
        print(f"Email with attachment sent. Message ID: {response.get('MessageId')}")
        return {
            'statusCode': 200,
            'message': 'Email with attachment sent successfully',
            'message_id': response.get('MessageId')
        }
        
    except Exception as e:
        error_msg = f"Error sending email with attachment: {str(e)}"
        print(error_msg)
        return {'statusCode': 500, 'error': error_msg}


# Example usage in lambda_handler (add this to lambda_trigger.py):
"""
# In lambda_handler, after investigation starts:
email_response = send_investigation_email(
    alarm_data=alarm_data,
    investigation_response=investigation_response,
    recipients=['devops-team@company.com', 'oncall@company.com']
)
print(f"Email send result: {email_response}")
"""
