"""
AWS DevOps Agent Investigation Trigger Lambda - Complete with SES Integration
Automatically starts investigations when CloudWatch alarms fire and sends email notifications

Dependencies: boto3 (pre-installed in Lambda)
"""

import json
import boto3
import os
from datetime import datetime
from typing import Dict, Any, List
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

# Initialize AWS clients
devopsagent_client = boto3.client('devopsagent', region_name='us-east-1')
cloudwatch_client = boto3.client('cloudwatch', region_name='us-east-1')
sns_client = boto3.client('sns')
logs_client = boto3.client('logs')
ses_client = boto3.client('ses', region_name='us-east-1')

# Environment variables
AGENT_SPACE_ID = os.environ.get('AGENT_SPACE_ID')
SLACK_CHANNEL = os.environ.get('SLACK_CHANNEL', '#devops-investigations')
SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN')
SENDER_EMAIL = os.environ.get('SENDER_EMAIL', 'devops-agent@yourdomain.com')
RECIPIENT_EMAILS = [e.strip() for e in os.environ.get('RECIPIENT_EMAILS', '').split(',') if e.strip()]


# ============================================================================
# CLOUDWATCH ALARM PARSING
# ============================================================================

def parse_cloudwatch_alarm(sns_message: Dict[str, Any]) -> Dict[str, Any]:
    """Parse SNS message from CloudWatch alarm"""
    try:
        alarm_data = {
            'alarm_name': sns_message.get('AlarmName', 'Unknown'),
            'alarm_description': sns_message.get('AlarmDescription', ''),
            'state': sns_message.get('StateValue', 'ALARM'),
            'state_reason': sns_message.get('StateReason', ''),
            'alarm_arn': sns_message.get('AlarmArn', ''),
            'account_id': sns_message.get('AWSAccountId', ''),
            'region': sns_message.get('Region', 'us-east-1'),
            'trigger': sns_message.get('Trigger', {}),
            'timestamp': sns_message.get('StateChangeTime', datetime.utcnow().isoformat()),
        }
        return alarm_data
    except Exception as e:
        print(f"Error parsing CloudWatch alarm: {str(e)}")
        raise


def create_investigation_title(alarm_data: Dict[str, Any]) -> str:
    """Create a descriptive investigation title"""
    timestamp = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
    return f"[AUTO] {alarm_data['alarm_name']} - {timestamp}"


def create_investigation_description(alarm_data: Dict[str, Any]) -> str:
    """Create detailed investigation description"""
    trigger_info = alarm_data.get('trigger', {})
    
    description = f"""
Automatic Investigation Triggered by CloudWatch Alarm

**Alarm Details:**
- Name: {alarm_data['alarm_name']}
- Status: {alarm_data['state']}
- ARN: {alarm_data['alarm_arn']}
- Region: {alarm_data['region']}
- Account: {alarm_data['account_id']}

**State Reason:**
{alarm_data['state_reason']}

**Alarm Description:**
{alarm_data['alarm_description']}

**Metric Information:**
- Namespace: {trigger_info.get('Namespace', 'N/A')}
- MetricName: {trigger_info.get('MetricName', 'N/A')}
- Statistic: {trigger_info.get('Statistic', 'N/A')}
- Period: {trigger_info.get('Period', 'N/A')} seconds
- Threshold: {trigger_info.get('Threshold', 'N/A')}
- ComparisonOperator: {trigger_info.get('ComparisonOperator', 'N/A')}

**Investigation Focus Areas:**
1. Recent metric anomalies
2. Recent deployments or configuration changes
3. Related resource changes via CloudTrail
4. Log anomalies during the alarm period
5. Service dependency chain analysis
"""
    return description.strip()


# ============================================================================
# DEVOPS AGENT INVESTIGATION
# ============================================================================

def start_investigation(alarm_data: Dict[str, Any]) -> Dict[str, Any]:
    """Start investigation via AWS DevOps Agent API"""
    try:
        investigation_title = create_investigation_title(alarm_data)
        investigation_description = create_investigation_description(alarm_data)
        
        print(f"Starting investigation: {investigation_title}")
        print(f"Agent Space ID: {AGENT_SPACE_ID}")
        
        response = devopsagent_client.create_investigation(
            agentSpaceId=AGENT_SPACE_ID,
            investigationTitle=investigation_title,
            investigationDescription=investigation_description,
            investigationSource={
                'sourceType': 'ALARM',
                'sourceArn': alarm_data['alarm_arn']
            },
            includeCloudTrailEvents=True,
            includeDeploymentData=True,
            includeLogData=True
        )
        
        print(f"Investigation created successfully: {response}")
        return response
        
    except Exception as e:
        error_msg = f"Error starting investigation: {str(e)}"
        print(error_msg)
        raise


def get_alarm_metrics(alarm_data: Dict[str, Any]) -> List[Dict]:
    """Fetch recent metrics for the triggered alarm"""
    try:
        trigger = alarm_data.get('trigger', {})
        namespace = trigger.get('Namespace', 'AWS/EC2')
        metric_name = trigger.get('MetricName', 'CPUUtilization')
        dimensions = trigger.get('Dimensions', [])
        
        cloudwatch_dimensions = [
            {'Name': dim.get('name', ''), 'Value': dim.get('value', '')}
            for dim in dimensions if dim.get('name') and dim.get('value')
        ]
        
        response = cloudwatch_client.get_metric_statistics(
            Namespace=namespace,
            MetricName=metric_name,
            Dimensions=cloudwatch_dimensions,
            StartTime=datetime.utcnow().replace(minute=datetime.utcnow().minute - 10),
            EndTime=datetime.utcnow(),
            Period=60,
            Statistics=['Average', 'Maximum', 'Minimum']
        )
        
        return response.get('Datapoints', [])
        
    except Exception as e:
        print(f"Error fetching metrics: {str(e)}")
        return []


# ============================================================================
# EMAIL GENERATION AND SENDING
# ============================================================================

def create_investigation_html_email(alarm_data: Dict[str, Any], investigation_response: Dict[str, Any]) -> str:
    """Create rich HTML email with investigation analysis"""
    investigation_id = investigation_response.get('investigationId', 'Unknown')
    console_url = f"https://us-east-1.console.aws.amazon.com/cloudwatch/home?region=us-east-1#alarmsV2:alarmFilter={alarm_data['alarm_name']}"
    
    html_body = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
            }}
            .container {{
                max-width: 800px;
                margin: 20px auto;
                background-color: #ffffff;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                overflow: hidden;
            }}
            .header {{
                background: linear-gradient(135deg, #FF9900 0%, #FF6B35 100%);
                color: white;
                padding: 30px;
                text-align: center;
            }}
            .header h1 {{
                margin: 0;
                font-size: 24px;
                font-weight: 600;
            }}
            .status-badge {{
                display: inline-block;
                background-color: rgba(255,255,255,0.3);
                padding: 8px 16px;
                border-radius: 4px;
                margin-top: 10px;
                font-size: 14px;
            }}
            .content {{
                padding: 30px;
            }}
            .section {{
                margin-bottom: 25px;
                padding-bottom: 20px;
                border-bottom: 1px solid #e0e0e0;
            }}
            .section:last-child {{
                border-bottom: none;
                margin-bottom: 0;
                padding-bottom: 0;
            }}
            .section-title {{
                font-size: 16px;
                font-weight: 600;
                color: #232f3e;
                margin-bottom: 12px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }}
            .detail-row {{
                display: flex;
                padding: 8px 0;
                border-bottom: 1px solid #f0f0f0;
            }}
            .detail-row:last-child {{
                border-bottom: none;
            }}
            .detail-label {{
                font-weight: 600;
                color: #555;
                width: 180px;
                flex-shrink: 0;
            }}
            .detail-value {{
                color: #232f3e;
                word-break: break-word;
                flex: 1;
                font-family: 'Courier New', monospace;
                font-size: 12px;
            }}
            .alert-box {{
                background-color: #fff3cd;
                border-left: 4px solid #ffc107;
                padding: 15px;
                margin: 15px 0;
                border-radius: 4px;
            }}
            .alert-title {{
                font-weight: 600;
                color: #856404;
                margin-bottom: 8px;
            }}
            .alert-content {{
                color: #856404;
                font-size: 13px;
                line-height: 1.6;
            }}
            .metric-box {{
                background-color: #f8f9fa;
                border: 1px solid #e9ecef;
                padding: 15px;
                border-radius: 4px;
                margin: 10px 0;
            }}
            .metric-value {{
                font-size: 18px;
                font-weight: 700;
                color: #FF9900;
            }}
            .metric-label {{
                font-size: 12px;
                color: #666;
                text-transform: uppercase;
            }}
            .cta-button {{
                display: inline-block;
                background-color: #FF9900;
                color: white;
                padding: 12px 24px;
                text-decoration: none;
                border-radius: 4px;
                margin-top: 15px;
                font-weight: 600;
                font-size: 14px;
            }}
            .cta-button:hover {{
                background-color: #FF6B35;
            }}
            .footer {{
                background-color: #f5f5f5;
                padding: 20px;
                text-align: center;
                border-top: 1px solid #e0e0e0;
                font-size: 12px;
                color: #666;
            }}
            .timestamp {{
                color: #999;
                font-size: 12px;
                margin-top: 10px;
            }}
            code {{
                background-color: #f0f0f0;
                padding: 2px 6px;
                border-radius: 3px;
                font-family: 'Courier New', monospace;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🚨 DevOps Agent Investigation Triggered</h1>
                <div class="status-badge">Automatic Analysis in Progress</div>
            </div>
            
            <div class="content">
                <!-- Alert Section -->
                <div class="section">
                    <div class="section-title">Alarm Triggered</div>
                    <div class="detail-row">
                        <span class="detail-label">Alarm Name:</span>
                        <span class="detail-value"><strong>{alarm_data['alarm_name']}</strong></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status:</span>
                        <span class="detail-value"><strong>{alarm_data['state']}</strong></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Time:</span>
                        <span class="detail-value">{alarm_data['timestamp']}</span>
                    </div>
                </div>
                
                <!-- Alert Details -->
                <div class="alert-box">
                    <div class="alert-title">Reason for Alert</div>
                    <div class="alert-content">{alarm_data['state_reason']}</div>
                </div>
                
                <!-- Investigation Details -->
                <div class="section">
                    <div class="section-title">Investigation Details</div>
                    <div class="detail-row">
                        <span class="detail-label">Investigation ID:</span>
                        <span class="detail-value"><code>{investigation_id}</code></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">AWS Account:</span>
                        <span class="detail-value">{alarm_data['account_id']}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Region:</span>
                        <span class="detail-value">{alarm_data['region']}</span>
                    </div>
                </div>
                
                <!-- Metric Information -->
                <div class="section">
                    <div class="section-title">Metric Information</div>
                    <div class="metric-box">
                        <div class="metric-label">Metric Name</div>
                        <div class="metric-value">{alarm_data['trigger'].get('MetricName', 'N/A')}</div>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Namespace:</span>
                        <span class="detail-value">{alarm_data['trigger'].get('Namespace', 'N/A')}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Threshold:</span>
                        <span class="detail-value">{alarm_data['trigger'].get('Threshold', 'N/A')}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Statistic:</span>
                        <span class="detail-value">{alarm_data['trigger'].get('Statistic', 'N/A')}</span>
                    </div>
                </div>
                
                <!-- Next Steps -->
                <div class="section">
                    <div class="section-title">What Happens Next</div>
                    <p style="color: #666; line-height: 1.6;">
                        AWS DevOps Agent is now automatically investigating this alarm. It will:
                    </p>
                    <ul style="color: #666; line-height: 1.8;">
                        <li>Analyze CloudWatch metrics from the past 24 hours</li>
                        <li>Review CloudTrail events for recent changes (90 days)</li>
                        <li>Examine application logs and traces</li>
                        <li>Identify recently deployed code changes</li>
                        <li>Generate a root cause hypothesis</li>
                        <li>Provide remediation recommendations</li>
                    </ul>
                    
                    <a href="https://us-east-1.console.aws.amazon.com/devopsagent" class="cta-button">
                        📊 View Investigation Results
                    </a>
                </div>
                
                <!-- Resources -->
                <div class="section">
                    <div class="section-title">Useful Links</div>
                    <div class="detail-row" style="border-bottom: none;">
                        <a href="{console_url}" style="color: #FF9900; text-decoration: none; font-weight: 500;">
                            → View CloudWatch Alarm
                        </a>
                    </div>
                    <div class="detail-row" style="border-bottom: none;">
                        <a href="https://docs.aws.amazon.com/devopsagent/" style="color: #FF9900; text-decoration: none; font-weight: 500;">
                            → DevOps Agent Documentation
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="footer">
                <p>This email was automatically sent by AWS DevOps Agent</p>
                <div class="timestamp">
                    Investigation ID: {investigation_id}<br>
                    Sent: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}
                </div>
            </div>
        </div>
    </body>
    </html>
    """
    return html_body


def create_plain_text_email(alarm_data: Dict[str, Any], investigation_response: Dict[str, Any]) -> str:
    """Create plain text version of investigation email"""
    investigation_id = investigation_response.get('investigationId', 'Unknown')
    
    text_body = f"""
DevOps Agent Investigation Triggered
=====================================

ALARM TRIGGERED
---------------
Alarm Name: {alarm_data['alarm_name']}
Status: {alarm_data['state']}
Time: {alarm_data['timestamp']}

REASON FOR ALERT
----------------
{alarm_data['state_reason']}

INVESTIGATION DETAILS
---------------------
Investigation ID: {investigation_id}
AWS Account: {alarm_data['account_id']}
Region: {alarm_data['region']}

METRIC INFORMATION
------------------
Metric Name: {alarm_data['trigger'].get('MetricName', 'N/A')}
Namespace: {alarm_data['trigger'].get('Namespace', 'N/A')}
Threshold: {alarm_data['trigger'].get('Threshold', 'N/A')}
Statistic: {alarm_data['trigger'].get('Statistic', 'N/A')}

WHAT HAPPENS NEXT
-----------------
AWS DevOps Agent is now automatically investigating this alarm. It will:
- Analyze CloudWatch metrics from the past 24 hours
- Review CloudTrail events for recent changes (90 days)
- Examine application logs and traces
- Identify recently deployed code changes
- Generate a root cause hypothesis
- Provide remediation recommendations

VIEW RESULTS
-----------
Console: https://us-east-1.console.aws.amazon.com/devopsagent

---
This email was automatically sent by AWS DevOps Agent
Timestamp: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}
Investigation ID: {investigation_id}
    """
    return text_body.strip()


def send_investigation_email(
    alarm_data: Dict[str, Any],
    investigation_response: Dict[str, Any],
    recipients: List[str] = None
) -> Dict[str, Any]:
    """Send investigation email via AWS SES"""
    
    if not recipients:
        recipients = RECIPIENT_EMAILS
    
    # Filter out empty strings
    recipients = [r.strip() for r in recipients if r.strip()]
    
    if not recipients:
        print("No recipient emails configured. Skipping email send.")
        return {'statusCode': 204, 'message': 'No recipients configured'}
    
    if not SENDER_EMAIL or SENDER_EMAIL == 'devops-agent@yourdomain.com':
        print("SENDER_EMAIL not properly configured in environment variables")
        return {'statusCode': 400, 'message': 'Sender email not configured'}
    
    try:
        # Create MIME message
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f"[DevOps Investigation] {alarm_data['alarm_name']}"
        msg['From'] = SENDER_EMAIL
        msg['To'] = ', '.join(recipients)
        
        # Create plain text and HTML versions
        text_part = MIMEText(
            create_plain_text_email(alarm_data, investigation_response),
            'plain'
        )
        html_part = MIMEText(
            create_investigation_html_email(alarm_data, investigation_response),
            'html'
        )
        
        # Attach both versions (plain text first, then HTML)
        msg.attach(text_part)
        msg.attach(html_part)
        
        # Send via SES
        response = ses_client.send_raw_email(
            Source=SENDER_EMAIL,
            Destinations=recipients,
            RawMessage={'Data': msg.as_string()}
        )
        
        print(f"Email sent successfully. Message ID: {response.get('MessageId')}")
        return {
            'statusCode': 200,
            'message': 'Email sent successfully',
            'message_id': response.get('MessageId'),
            'recipients': recipients
        }
        
    except ses_client.exceptions.MessageRejected as e:
        error_msg = f"SES rejected message: {str(e)}"
        print(error_msg)
        return {'statusCode': 400, 'error': error_msg}
    
    except ses_client.exceptions.AccountSendingPausedException as e:
        error_msg = f"Account sending is paused: {str(e)}"
        print(error_msg)
        return {'statusCode': 400, 'error': error_msg}
    
    except Exception as e:
        error_msg = f"Error sending email via SES: {str(e)}"
        print(error_msg)
        return {'statusCode': 500, 'error': error_msg}


# ============================================================================
# NOTIFICATIONS (SLACK)
# ============================================================================

def send_slack_notification(alarm_data: Dict[str, Any], investigation_response: Dict[str, Any]) -> None:
    """Send Slack notification about investigation start (optional)"""
    try:
        if not SNS_TOPIC_ARN:
            print("SNS_TOPIC_ARN not configured, skipping Slack notification")
            return
        
        investigation_id = investigation_response.get('investigationId', 'Unknown')
        
        message = {
            'channel': SLACK_CHANNEL,
            'username': 'AWS DevOps Agent',
            'icon_emoji': ':robot_face:',
            'attachments': [
                {
                    'color': 'danger',
                    'title': f":alarm_clock: CloudWatch Alarm Triggered",
                    'text': f"Investigation automatically started for: {alarm_data['alarm_name']}",
                    'fields': [
                        {
                            'title': 'Alarm Name',
                            'value': alarm_data['alarm_name'],
                            'short': True
                        },
                        {
                            'title': 'Status',
                            'value': alarm_data['state'],
                            'short': True
                        },
                        {
                            'title': 'Region',
                            'value': alarm_data['region'],
                            'short': True
                        },
                        {
                            'title': 'Investigation ID',
                            'value': investigation_id,
                            'short': True
                        },
                        {
                            'title': 'State Reason',
                            'value': alarm_data['state_reason'],
                            'short': False
                        }
                    ],
                    'footer': 'AWS DevOps Agent',
                    'ts': int(datetime.utcnow().timestamp())
                }
            ]
        }
        
        sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=json.dumps(message),
            Subject=f"DevOps Investigation Started: {alarm_data['alarm_name']}"
        )
        
        print("Slack notification sent successfully")
        
    except Exception as e:
        print(f"Error sending Slack notification: {str(e)}")


# ============================================================================
# LOGGING
# ============================================================================

def log_investigation_details(alarm_data: Dict[str, Any], investigation_response: Dict[str, Any]) -> None:
    """Log investigation details to CloudWatch Logs"""
    try:
        log_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'alarm_name': alarm_data['alarm_name'],
            'investigation_id': investigation_response.get('investigationId'),
            'alarm_arn': alarm_data['alarm_arn'],
            'account_id': alarm_data['account_id'],
            'region': alarm_data['region'],
            'status': 'INVESTIGATION_STARTED'
        }
        
        print(f"Investigation logged: {json.dumps(log_entry)}")
        
    except Exception as e:
        print(f"Error logging investigation: {str(e)}")


# ============================================================================
# MAIN LAMBDA HANDLER
# ============================================================================

def lambda_handler(event, context):
    """
    Main Lambda handler
    
    Event structure (from SNS):
    {
        "Records": [
            {
                "Sns": {
                    "Message": "<CloudWatch alarm message in JSON>"
                }
            }
        ]
    }
    """
    
    print(f"Event received: {json.dumps(event, indent=2)}")
    print(f"Agent Space ID: {AGENT_SPACE_ID}")
    
    try:
        # Validate Agent Space ID
        if not AGENT_SPACE_ID:
            error_msg = "AGENT_SPACE_ID environment variable not set"
            print(error_msg)
            return {
                'statusCode': 400,
                'body': json.dumps({'error': error_msg})
            }
        
        # Extract SNS message
        if 'Records' not in event or len(event['Records']) == 0:
            error_msg = "No SNS records found in event"
            print(error_msg)
            return {
                'statusCode': 400,
                'body': json.dumps({'error': error_msg})
            }
        
        sns_message_str = event['Records'][0]['Sns']['Message']
        sns_message = json.loads(sns_message_str)
        
        print(f"SNS Message: {json.dumps(sns_message, indent=2)}")
        
        # Parse alarm data
        alarm_data = parse_cloudwatch_alarm(sns_message)
        print(f"Parsed alarm data: {json.dumps(alarm_data, indent=2)}")
        
        # Only trigger investigation for ALARM state
        if alarm_data['state'] != 'ALARM':
            print(f"Alarm state is {alarm_data['state']}, skipping investigation")
            return {
                'statusCode': 200,
                'body': json.dumps({'message': f"Alarm state {alarm_data['state']}, no investigation triggered"})
            }
        
        # Fetch recent metrics
        metrics = get_alarm_metrics(alarm_data)
        print(f"Recent metrics: {json.dumps(metrics, default=str)}")
        
        # Start investigation
        investigation_response = start_investigation(alarm_data)
        
        # Log investigation
        log_investigation_details(alarm_data, investigation_response)
        
        # Send email notification
        email_response = send_investigation_email(alarm_data, investigation_response)
        print(f"Email response: {email_response}")
        
        # Send Slack notification (optional)
        send_slack_notification(alarm_data, investigation_response)
        
        # Return success
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Investigation started and notifications sent',
                'investigationId': investigation_response.get('investigationId'),
                'alarmName': alarm_data['alarm_name'],
                'emailStatus': email_response.get('statusCode'),
                'timestamp': datetime.utcnow().isoformat()
            })
        }
        
    except Exception as e:
        error_msg = f"Lambda execution failed: {str(e)}"
        print(error_msg)
        
        return {
            'statusCode': 500,
            'body': json.dumps({'error': error_msg})
        }
