# Complete Lambda with SES - Summary

## 📦 What You Have

**Single Production-Ready Lambda Function** with complete integration:
- ✅ CloudWatch alarm detection & parsing
- ✅ DevOps Agent investigation triggering
- ✅ **Email notifications via SES (rich HTML)**
- ✅ Optional Slack integration
- ✅ Comprehensive CloudWatch logging
- ✅ Error handling & retries

---

## 🎯 File: `lambda_complete_with_ses.py`

**One complete file containing:**

### Sections
1. **Imports & Client Setup** - AWS SDK clients
2. **Environment Variables** - Configuration from Lambda env
3. **CloudWatch Parsing** - Extract alarm data from SNS
4. **DevOps Agent** - Trigger investigations
5. **Email Generation** - Rich HTML + plain text
6. **SES Sending** - Send emails with error handling
7. **Slack Notifications** - Optional slack alerts
8. **Logging** - CloudWatch audit trail
9. **Lambda Handler** - Orchestrates everything

### Key Functions
- `parse_cloudwatch_alarm()` - Extract alarm details
- `create_investigation_html_email()` - Generate HTML email
- `create_plain_text_email()` - Generate text version
- `send_investigation_email()` - Send via SES
- `start_investigation()` - Call DevOps Agent API
- `send_slack_notification()` - Post to Slack
- `lambda_handler()` - Main entry point

---

## ⚡ Quick Setup

### 1. Verify Email (SES)
```bash
aws ses verify-email-identity --email-address devops-agent@company.com --region us-east-1
# Click verification link in email inbox
```

### 2. Update IAM Role
```bash
cat > combined-policy.json << 'EOF'
{"Version":"2012-10-17","Statement":[{"Sid":"DevOpsAgentAccess","Effect":"Allow","Action":["devopsagent:CreateInvestigation","devopsagent:DescribeInvestigation","devopsagent:ListInvestigations"],"Resource":"*"},{"Sid":"CloudWatchAccess","Effect":"Allow","Action":["cloudwatch:GetMetricStatistics","cloudwatch:ListMetrics","cloudwatch:DescribeAlarms"],"Resource":"*"},{"Sid":"SESAccess","Effect":"Allow","Action":["ses:SendEmail","ses:SendRawEmail"],"Resource":"*"},{"Sid":"SNSPublish","Effect":"Allow","Action":["sns:Publish"],"Resource":"*"},{"Sid":"CloudWatchLogs","Effect":"Allow","Action":["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],"Resource":"arn:aws:logs:*:*:*"}]}
EOF
aws iam put-role-policy --role-name DevOpsAgentInvestigationLambdaRole --policy-name DevOpsAgentCombinedPolicy --policy-document file://combined-policy.json
```

### 3. Package & Deploy
```bash
zip lambda_complete_with_ses.zip lambda_complete_with_ses.py

aws lambda update-function-code \
  --function-name DevOpsAgentInvestigationTrigger \
  --zip-file fileb://lambda_complete_with_ses.zip \
  --region us-east-1
```

### 4. Set Environment Variables
```bash
aws lambda update-function-configuration \
  --function-name DevOpsAgentInvestigationTrigger \
  --environment Variables="{
    AGENT_SPACE_ID=space-xxxxx,
    SENDER_EMAIL=devops-agent@company.com,
    RECIPIENT_EMAILS=team@company.com,manager@company.com
  }" \
  --region us-east-1
```

### 5. Test
```bash
aws lambda invoke \
  --function-name DevOpsAgentInvestigationTrigger \
  --payload file://test-event.json \
  response.json

# Check email inbox for test notification
```

---

## 📧 Email Output

**Subject:** `[DevOps Investigation] YourAlarmName`

**Contains:**
- Alarm name, status, timestamp
- Alert reason
- Metric details (namespace, threshold, statistic)
- Investigation ID (clickable link)
- AWS account & region
- What DevOps Agent analyzes
- Useful links
- Professional AWS branding

---

## 🔄 Complete Flow

```
CloudWatch Alarm (threshold breach)
    ↓
SNS Topic (receives alarm notification)
    ↓
Lambda Function (DevOpsAgentInvestigationTrigger)
    ├─ Parse alarm data
    ├─ Call DevOps Agent API (investigation starts)
    ├─ Send email via SES (team notified immediately)
    ├─ Post to Slack (optional)
    └─ Log to CloudWatch (audit trail)
    ↓
DevOps Agent (automatic investigation)
    ├─ Analyze CloudWatch metrics (24 hours)
    ├─ Review CloudTrail events (90 days)
    ├─ Examine logs & traces
    ├─ Identify recent changes/deployments
    └─ Generate root cause hypothesis
    ↓
Results displayed in:
    ├─ DevOps Agent web app
    ├─ Slack updates (optional)
    └─ Email updates (optional)
```

---

## 🎨 Email Template

**Includes:**
- Professional header with AWS branding
- Alert status badge
- Alarm details section
- Alert reason highlighted
- Investigation details (ID, account, region)
- Metric information
- Next steps (what agent analyzes)
- Useful links
- Professional footer

**Plain text fallback** for email clients that don't support HTML

---

## 📝 Environment Variables

| Variable | Required | Purpose |
|----------|----------|---------|
| `AGENT_SPACE_ID` | ✅ YES | DevOps Agent space ID from console |
| `SENDER_EMAIL` | ✅ YES | Email to send from (must verify in SES) |
| `RECIPIENT_EMAILS` | ✅ YES | Comma-separated recipients |
| `SLACK_CHANNEL` | ❌ NO | Slack channel for alerts |
| `SNS_TOPIC_ARN` | ❌ NO | SNS topic for Slack integration |

---

## ✅ What's Handled

✅ **Error Handling**
- SES message rejection
- Account sending paused
- Invalid parameters
- Missing credentials

✅ **Edge Cases**
- Empty recipient list
- Unconfigured SES
- Non-ALARM state alarms (skipped)
- Missing alarm data

✅ **Logging**
- Every action logged to CloudWatch
- Investigation details recorded
- Email delivery status tracked
- Error messages detailed

✅ **Security**
- MIME multipart for security
- No credentials in code
- Uses environment variables
- Proper IAM scoping

---

## 🧪 Testing

### Test 1: Sample Event
```bash
aws lambda invoke \
  --function-name DevOpsAgentInvestigationTrigger \
  --payload file://test-event.json \
  response.json
```

### Test 2: Real Alarm
```bash
# SSH to EC2 and run:
stress-ng --cpu 1 --timeout 300s

# Monitor:
# 1. CloudWatch alarm → ALARM
# 2. Lambda invoked (~1 second)
# 3. Email sent (within 5 seconds)
# 4. DevOps Agent investigation starts
```

### Test 3: Check Logs
```bash
aws logs tail /aws/lambda/DevOpsAgentInvestigationTrigger --follow
```

---

## 💰 Cost

**AWS SES Pricing:**
- **First 62,000 emails/month: FREE** (from EC2/Lambda)
- Beyond that: $0.10 per 1,000 emails
- **Example:** 100 investigations = $0 (free tier)

---

## 📊 Metrics to Monitor

```bash
# Email send statistics
aws ses get-send-statistics

# Lambda invocations
aws cloudwatch get-metric-statistics \
  --namespace AWS/Lambda \
  --metric-name Invocations \
  --start-time $(date -u -d '1 day ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 3600 \
  --statistics Sum

# Lambda errors
aws cloudwatch get-metric-statistics \
  --namespace AWS/Lambda \
  --metric-name Errors \
  --start-time $(date -u -d '1 day ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 3600 \
  --statistics Sum
```

---

## 🔗 Integration Points

**This Lambda integrates with:**
- ✅ CloudWatch (alarms, metrics, logs)
- ✅ SNS (receives alarm notifications)
- ✅ SES (sends emails)
- ✅ DevOps Agent API (triggers investigations)
- ✅ Slack (optional notifications)
- ✅ Lambda (serverless execution)

**Can be extended with:**
- PagerDuty (incident creation)
- Jira (ticket creation)
- DynamoDB (audit trail)
- Custom alerting

---

## 🚨 Troubleshooting

| Problem | Solution |
|---------|----------|
| Email not sent | Check SES: `aws ses list-verified-email-addresses` |
| SENDER_EMAIL not found | Verify email: `aws ses verify-email-identity --email-address X` |
| Sandbox mode limit | Request production access in AWS Console |
| Investigation not starting | Check Agent Space ID is correct |
| Lambda errors | Check logs: `aws logs tail /aws/lambda/... --follow` |

---

## 🎓 What You Learned

1. **AWS DevOps Agent** - Automatic incident investigation
2. **Lambda + SNS integration** - Event-driven architecture
3. **AWS SES** - Email delivery at scale
4. **MIME emails** - Rich HTML + plain text
5. **Error handling** - Production-ready code
6. **IaC practices** - Infrastructure as Code

---

## 📚 Files Reference

| File | Purpose |
|------|---------|
| `lambda_complete_with_ses.py` | **Complete Lambda function** |
| `deploy-complete.md` | Detailed deployment guide |
| `test-event.json` | Sample SNS event for testing |
| `combined-policy.json` | IAM policy for SES access |

---

## 🏁 Final Checklist

- [ ] Email verified in SES
- [ ] IAM role has SES permissions
- [ ] Lambda function deployed
- [ ] Environment variables configured
- [ ] SNS subscription created
- [ ] CloudWatch alarms linked
- [ ] Test invocation successful
- [ ] Email received in inbox
- [ ] HTML rendered correctly
- [ ] Investigation ID clickable
- [ ] DevOps Agent console accessible

---

## 🎉 You're Ready!

Your complete automation is now in place:

```
CloudWatch Alarm
    ↓ (milliseconds)
Lambda Investigation Trigger
    ↓ (milliseconds)
Email to Team + DevOps Agent Analysis
    ↓ (seconds)
Root Cause Identification
```

**All automatic. Zero manual intervention.**

---

## 📞 Support

- [AWS SES Documentation](https://docs.aws.amazon.com/ses/)
- [AWS Lambda Documentation](https://docs.aws.amazon.com/lambda/)
- [AWS DevOps Agent Documentation](https://docs.aws.amazon.com/devopsagent/)

---

**Enjoy your automated incident investigation workflow! 🚀**
