# AWS Lambda + SNS Setup for DevOps Agent Investigation Trigger

## Prerequisites
- AWS CLI configured
- DevOps Agent Agent Space ID (from your PoC setup)
- CloudWatch alarms already created
- Appropriate IAM permissions

---

## Step 1: Create IAM Role for Lambda

**Save as: `trust-policy.json`**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "lambda.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

**Create the role:**
```bash
aws iam create-role \
  --role-name DevOpsAgentInvestigationLambdaRole \
  --assume-role-policy-document file://trust-policy.json \
  --region us-east-1
```

---

## Step 2: Create IAM Policy for Lambda

**Save as: `lambda-policy.json`**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "DevOpsAgentAccess",
      "Effect": "Allow",
      "Action": [
        "devopsagent:CreateInvestigation",
        "devopsagent:DescribeInvestigation",
        "devopsagent:ListInvestigations"
      ],
      "Resource": "*"
    },
    {
      "Sid": "CloudWatchAccess",
      "Effect": "Allow",
      "Action": [
        "cloudwatch:GetMetricStatistics",
        "cloudwatch:ListMetrics",
        "cloudwatch:DescribeAlarms"
      ],
      "Resource": "*"
    },
    {
      "Sid": "SNSPublish",
      "Effect": "Allow",
      "Action": [
        "sns:Publish"
      ],
      "Resource": "*"
    },
    {
      "Sid": "CloudWatchLogs",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "arn:aws:logs:*:*:*"
    }
  ]
}
```

**Attach policy to role:**
```bash
aws iam put-role-policy \
  --role-name DevOpsAgentInvestigationLambdaRole \
  --policy-name DevOpsAgentInvestigationPolicy \
  --policy-document file://lambda-policy.json \
  --region us-east-1
```

---

## Step 3: Create SNS Topic (for alarm notifications)

```bash
aws sns create-topic \
  --name devops-agent-alarm-triggers \
  --region us-east-1
```

**Output:** Save the Topic ARN (you'll need it)

Example: `arn:aws:sns:us-east-1:123456789012:devops-agent-alarm-triggers`

---

## Step 4: Package and Deploy Lambda Function

**1. Create function package:**
```bash
# Create deployment package
zip lambda_deployment.zip lambda_trigger.py

# Verify the zip
unzip -l lambda_deployment.zip
```

**2. Deploy Lambda function:**
```bash
# Replace YOUR_AGENT_SPACE_ID with actual ID from DevOps Agent console
aws lambda create-function \
  --function-name DevOpsAgentInvestigationTrigger \
  --runtime python3.11 \
  --role arn:aws:iam::YOUR_ACCOUNT_ID:role/DevOpsAgentInvestigationLambdaRole \
  --handler lambda_trigger.lambda_handler \
  --zip-file fileb://lambda_deployment.zip \
  --timeout 60 \
  --memory-size 256 \
  --region us-east-1 \
  --environment Variables="{
    AGENT_SPACE_ID=YOUR_AGENT_SPACE_ID,
    SLACK_CHANNEL=#devops-investigations,
    SNS_TOPIC_ARN=arn:aws:sns:us-east-1:YOUR_ACCOUNT_ID:devops-agent-alarm-triggers
  }" \
  --tags "Project=DevOpsAgent,Environment=PoC"
```

**3. Verify deployment:**
```bash
aws lambda get-function \
  --function-name DevOpsAgentInvestigationTrigger \
  --region us-east-1
```

---

## Step 5: Subscribe Lambda to SNS Topic

```bash
aws lambda add-permission \
  --function-name DevOpsAgentInvestigationTrigger \
  --statement-id AllowSNSInvoke \
  --action lambda:InvokeFunction \
  --principal sns.amazonaws.com \
  --source-arn arn:aws:sns:us-east-1:YOUR_ACCOUNT_ID:devops-agent-alarm-triggers \
  --region us-east-1

# Subscribe Lambda to SNS topic
aws sns subscribe \
  --topic-arn arn:aws:sns:us-east-1:YOUR_ACCOUNT_ID:devops-agent-alarm-triggers \
  --protocol lambda \
  --notification-endpoint arn:aws:lambda:us-east-1:YOUR_ACCOUNT_ID:function/DevOpsAgentInvestigationTrigger \
  --region us-east-1
```

---

## Step 6: Update CloudWatch Alarm to Publish to SNS

**For each alarm you want to trigger investigations:**

### Option A: AWS CLI

```bash
aws cloudwatch put-metric-alarm \
  --alarm-name YourAlarmName \
  --alarm-description "Alarm that triggers DevOps Agent investigation" \
  --metric-name CPUUtilization \
  --namespace AWS/EC2 \
  --statistic Average \
  --period 300 \
  --threshold 80 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2 \
  --alarm-actions arn:aws:sns:us-east-1:YOUR_ACCOUNT_ID:devops-agent-alarm-triggers \
  --region us-east-1
```

### Option B: AWS Console

1. Go to **CloudWatch** → **Alarms** → Select your alarm
2. Click **Edit**
3. Scroll to **Notification** section
4. Under **Alarm State Trigger**, select **In alarm**
5. Click **Add action** → Select **Send a message to an SNS topic**
6. Choose topic: `devops-agent-alarm-triggers`
7. Click **Update Alarm**

---

## Step 7: Test the Integration

### Test 1: Manual SNS Publish

```bash
# Send test message to SNS
aws sns publish \
  --topic-arn arn:aws:sns:us-east-1:YOUR_ACCOUNT_ID:devops-agent-alarm-triggers \
  --message '{
    "AlarmName": "Test-CPU-Alarm",
    "AlarmDescription": "Test alarm for DevOps Agent",
    "AWSAccountId": "YOUR_ACCOUNT_ID",
    "NewStateValue": "ALARM",
    "NewStateReason": "Threshold Crossed: 1 out of 1 datapoints was greater than the threshold (80.0)",
    "StateChangeTime": "2026-01-28T17:30:00Z",
    "Region": "us-east-1",
    "AlarmArn": "arn:aws:cloudwatch:us-east-1:YOUR_ACCOUNT_ID:alarm:Test-CPU-Alarm",
    "StateUpdatedTimestamp": "2026-01-28T17:30:00Z",
    "Trigger": {
      "MetricName": "CPUUtilization",
      "Namespace": "AWS/EC2",
      "StatisticType": "Statistic",
      "Statistic": "AVERAGE",
      "Dimensions": [
        {
          "name": "InstanceId",
          "value": "i-1234567890abcdef0"
        }
      ],
      "Period": 300,
      "EvaluationPeriods": 2,
      "Threshold": 80.0,
      "ComparisonOperator": "GreaterThanThreshold",
      "TreatMissingData": "notBreaching"
    }
  }' \
  --region us-east-1
```

### Test 2: Check Lambda Logs

```bash
# View Lambda execution logs
aws logs tail /aws/lambda/DevOpsAgentInvestigationTrigger \
  --follow \
  --region us-east-1
```

**Expected output:**
```
START RequestId: abc123...
Event received: {...}
Parsed alarm data: {...}
Starting investigation: [AUTO] Test-CPU-Alarm - 2026-01-28 17:30:00 UTC
Investigation created successfully: {'investigationId': 'inv-xxxxx'}
Investigation logged: {...}
END RequestId: abc123...
```

### Test 3: Check DevOps Agent Web App

1. Go to DevOps Agent console → **Launch Web App**
2. Navigate to **Incident Response**
3. Look for new investigation with title `[AUTO] Test-CPU-Alarm`
4. Verify it contains metrics, logs, and analysis

---

## Step 8: Trigger Real Alarm (Optional)

**Generate CPU load on an EC2 instance:**

```bash
# SSH into your EC2 instance
ssh -i your-key.pem ec2-user@your-instance-ip

# Run CPU stress test
stress-ng --cpu 1 --timeout 300s

# Or use a simpler command
while true; do :; done &
```

Monitor:
- CloudWatch Alarm changes state to ALARM
- Lambda is invoked automatically
- Investigation appears in DevOps Agent

---

## Environment Variables Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `AGENT_SPACE_ID` | Your DevOps Agent Space ID | `space-abc123def456` |
| `SLACK_CHANNEL` | Slack channel for notifications | `#devops-investigations` |
| `SNS_TOPIC_ARN` | SNS topic for Slack messages | `arn:aws:sns:us-east-1:123456789012:...` |

**Update environment variables:**
```bash
aws lambda update-function-configuration \
  --function-name DevOpsAgentInvestigationTrigger \
  --environment Variables="{AGENT_SPACE_ID=YOUR_NEW_ID}" \
  --region us-east-1
```

---

## Troubleshooting

### Lambda Execution Failed

1. Check CloudWatch Logs:
```bash
aws logs tail /aws/lambda/DevOpsAgentInvestigationTrigger --follow
```

2. Verify IAM role has permissions:
```bash
aws iam get-role-policy \
  --role-name DevOpsAgentInvestigationLambdaRole \
  --policy-name DevOpsAgentInvestigationPolicy
```

3. Test Lambda directly:
```bash
aws lambda invoke \
  --function-name DevOpsAgentInvestigationTrigger \
  --payload file://test-event.json \
  --region us-east-1 \
  response.json

cat response.json
```

### No Investigation Started

1. Check if alarm state is `ALARM` (not `OK`)
2. Verify `AGENT_SPACE_ID` is correct
3. Check if DevOps Agent role has CloudWatch permissions
4. Verify SNS subscription exists and is confirmed

---

## Cleanup

```bash
# Delete Lambda function
aws lambda delete-function \
  --function-name DevOpsAgentInvestigationTrigger \
  --region us-east-1

# Delete SNS topic
aws sns delete-topic \
  --topic-arn arn:aws:sns:us-east-1:YOUR_ACCOUNT_ID:devops-agent-alarm-triggers \
  --region us-east-1

# Delete IAM role and policy
aws iam delete-role-policy \
  --role-name DevOpsAgentInvestigationLambdaRole \
  --policy-name DevOpsAgentInvestigationPolicy

aws iam delete-role \
  --role-name DevOpsAgentInvestigationLambdaRole
```

---

## Architecture Diagram

```
CloudWatch Alarm (ALARM state)
          ↓
    SNS Topic
          ↓
Lambda Function (DevOpsAgentInvestigationTrigger)
    ├─ Parses alarm data
    ├─ Fetches recent metrics
    ├─ Creates investigation
    └─ Sends Slack notification
          ↓
DevOps Agent
    ├─ Analyzes CloudWatch metrics
    ├─ Pulls CloudTrail events
    ├─ Examines logs
    └─ Generates root cause
          ↓
Web App + Slack
    └─ Displays investigation results
```

---

## Next Steps

1. **Test the flow** with manual SNS publish
2. **Create a real alarm** that breaches threshold
3. **Monitor Lambda logs** to verify execution
4. **Customize investigation context** in `create_investigation_description()` as needed
5. **Set up Slack integration** in DevOps Agent for real-time notifications
6. **Create additional alarms** pointing to the same SNS topic

---

## Additional Resources

- [AWS Lambda Documentation](https://docs.aws.amazon.com/lambda/)
- [AWS DevOps Agent API Reference](https://docs.aws.amazon.com/devopsagent/latest/userguide/)
- [CloudWatch Alarms](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/)
