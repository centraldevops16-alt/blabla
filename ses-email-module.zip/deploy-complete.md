# Complete Lambda with SES Integration - Deployment Guide

## Quick Deploy (All-in-One)

This is a single, complete Lambda function with SES email integration fully included.

---

## Step 1: Prepare Prerequisites

### Verify Email Address in SES
```bash
aws ses verify-email-identity \
  --email-address devops-agent@company.com \
  --region us-east-1

# Check your email inbox and click AWS verification link
```

### Verify Account
```bash
aws sts get-caller-identity
```

---

## Step 2: Update Lambda Role (Add SES Permissions)

```bash
# Create combined policy with SES access
cat > combined-policy.json << 'EOF'
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "DevOpsAgentAccess",
      "Effect": "Allow",
      "Action": [
        "devopsagent:CreateInvestigation",
        "devopsagent:DescribeInvestigation",
        "devopsagent:ListInvestigations"
      ],
      "Resource": "*"
    },
    {
      "Sid": "CloudWatchAccess",
      "Effect": "Allow",
      "Action": [
        "cloudwatch:GetMetricStatistics",
        "cloudwatch:ListMetrics",
        "cloudwatch:DescribeAlarms"
      ],
      "Resource": "*"
    },
    {
      "Sid": "SESAccess",
      "Effect": "Allow",
      "Action": [
        "ses:SendEmail",
        "ses:SendRawEmail"
      ],
      "Resource": "*"
    },
    {
      "Sid": "SNSPublish",
      "Effect": "Allow",
      "Action": [
        "sns:Publish"
      ],
      "Resource": "*"
    },
    {
      "Sid": "CloudWatchLogs",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "arn:aws:logs:*:*:*"
    }
  ]
}
EOF

# Attach to Lambda role
aws iam put-role-policy \
  --role-name DevOpsAgentInvestigationLambdaRole \
  --policy-name DevOpsAgentCombinedPolicy \
  --policy-document file://combined-policy.json \
  --region us-east-1
```

---

## Step 3: Deploy Lambda Function

### Option A: Create New Function

```bash
# Get your AWS account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

# Create function
aws lambda create-function \
  --function-name DevOpsAgentInvestigationTrigger \
  --runtime python3.11 \
  --role arn:aws:iam::${ACCOUNT_ID}:role/DevOpsAgentInvestigationLambdaRole \
  --handler lambda_complete_with_ses.lambda_handler \
  --zip-file fileb://lambda_complete_with_ses.zip \
  --timeout 60 \
  --memory-size 256 \
  --region us-east-1 \
  --environment Variables="{
    AGENT_SPACE_ID=YOUR_AGENT_SPACE_ID,
    SENDER_EMAIL=devops-agent@company.com,
    RECIPIENT_EMAILS=team@company.com,manager@company.com,
    SLACK_CHANNEL=#devops-investigations,
    SNS_TOPIC_ARN=arn:aws:sns:us-east-1:${ACCOUNT_ID}:devops-agent-notifications
  }"
```

### Option B: Update Existing Function

```bash
# Update function code
aws lambda update-function-code \
  --function-name DevOpsAgentInvestigationTrigger \
  --zip-file fileb://lambda_complete_with_ses.zip \
  --region us-east-1

# Update environment variables
aws lambda update-function-configuration \
  --function-name DevOpsAgentInvestigationTrigger \
  --environment Variables="{
    AGENT_SPACE_ID=YOUR_AGENT_SPACE_ID,
    SENDER_EMAIL=devops-agent@company.com,
    RECIPIENT_EMAILS=team@company.com,manager@company.com,
    SLACK_CHANNEL=#devops-investigations
  }" \
  --region us-east-1
```

---

## Step 4: Package the Function

```bash
# Create deployment package
zip lambda_complete_with_ses.zip lambda_complete_with_ses.py

# Verify package
unzip -l lambda_complete_with_ses.zip
```

---

## Step 5: Configure SNS Subscription

```bash
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
LAMBDA_ARN="arn:aws:lambda:us-east-1:${ACCOUNT_ID}:function/DevOpsAgentInvestigationTrigger"
SNS_TOPIC_ARN="arn:aws:sns:us-east-1:${ACCOUNT_ID}:devops-agent-alarm-triggers"

# Grant Lambda permission to be invoked by SNS
aws lambda add-permission \
  --function-name DevOpsAgentInvestigationTrigger \
  --statement-id AllowSNSInvoke \
  --action lambda:InvokeFunction \
  --principal sns.amazonaws.com \
  --source-arn ${SNS_TOPIC_ARN} \
  --region us-east-1

# Subscribe Lambda to SNS topic
aws sns subscribe \
  --topic-arn ${SNS_TOPIC_ARN} \
  --protocol lambda \
  --notification-endpoint ${LAMBDA_ARN} \
  --region us-east-1
```

---

## Step 6: Update CloudWatch Alarms

For each alarm you want to trigger investigations:

```bash
aws cloudwatch put-metric-alarm \
  --alarm-name MyTestAlarm \
  --alarm-description "Test alarm for DevOps Agent" \
  --metric-name CPUUtilization \
  --namespace AWS/EC2 \
  --statistic Average \
  --period 300 \
  --threshold 80 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2 \
  --alarm-actions arn:aws:sns:us-east-1:${ACCOUNT_ID}:devops-agent-alarm-triggers \
  --region us-east-1
```

---

## Step 7: Test the Integration

### Test 1: Invoke Lambda with Sample Event

```bash
aws lambda invoke \
  --function-name DevOpsAgentInvestigationTrigger \
  --payload file://test-event.json \
  --region us-east-1 \
  response.json

# Check response
cat response.json
```

### Test 2: Monitor Logs

```bash
# View logs in real-time
aws logs tail /aws/lambda/DevOpsAgentInvestigationTrigger \
  --follow \
  --region us-east-1
```

### Test 3: Check Email

Look for email with:
- **Subject**: `[DevOps Investigation] MyTestAlarm`
- **From**: `devops-agent@company.com`
- **To**: Recipients from `RECIPIENT_EMAILS`
- **Content**: Rich HTML with alarm details

---

## Environment Variables Explained

| Variable | Required | Purpose | Example |
|----------|----------|---------|---------|
| `AGENT_SPACE_ID` | ✅ YES | DevOps Agent space to use | `space-abc123def456` |
| `SENDER_EMAIL` | ✅ YES | Email to send from (must be verified in SES) | `devops-agent@company.com` |
| `RECIPIENT_EMAILS` | ✅ YES | Comma-separated recipients | `team@company.com,mgr@company.com` |
| `SLACK_CHANNEL` | ❌ NO | Slack channel for alerts | `#devops-incidents` |
| `SNS_TOPIC_ARN` | ❌ NO | SNS topic for Slack | `arn:aws:sns:us-east-1:...` |

---

## File Structure

```
lambda_complete_with_ses.py  (MAIN FILE - contains everything)
├── Imports & AWS clients
├── Environment variables
├── CloudWatch alarm parsing
├── DevOps Agent investigation logic
├── Email generation (HTML + plain text)
├── SES email sending
├── Slack notifications
├── CloudWatch logging
└── Lambda handler (orchestrates everything)
```

---

## Features Included

✅ **CloudWatch Alarm Detection**
- Parses SNS messages from CloudWatch alarms
- Extracts metric details
- Only processes ALARM state (not OK/INSUFFICIENT_DATA)

✅ **DevOps Agent Integration**
- Creates automatic investigations
- Includes alarm context
- Enables CloudTrail, deployment, and log analysis

✅ **Email Notifications (SES)**
- Rich HTML email template
- Professional AWS branding
- Plain text fallback
- Alarm details, investigation ID, next steps
- Clickable links to console

✅ **Optional Slack Notifications**
- Sends to Slack if SNS_TOPIC_ARN configured
- Colored attachments
- Investigation ID included

✅ **Comprehensive Logging**
- All actions logged to CloudWatch
- Audit trail maintained
- Error messages detailed

---

## Testing Scenarios

### Scenario 1: Test with Synthetic Alarm

```bash
# Generate test event
cat > test-alarm.json << 'EOF'
{
  "Records": [{
    "Sns": {
      "Message": "{\"AlarmName\":\"Test-CPU-High\",\"StateValue\":\"ALARM\",\"StateReason\":\"Threshold exceeded\",\"AWSAccountId\":\"123456789012\",\"Region\":\"us-east-1\",\"AlarmArn\":\"arn:aws:cloudwatch:us-east-1:123456789012:alarm:Test-CPU-High\",\"Trigger\":{\"MetricName\":\"CPUUtilization\",\"Namespace\":\"AWS/EC2\",\"Threshold\":80}}"
    }
  }]
}
EOF

# Invoke
aws lambda invoke \
  --function-name DevOpsAgentInvestigationTrigger \
  --payload file://test-alarm.json \
  response.json

# Check result
cat response.json
```

### Scenario 2: Test with Real Alarm

```bash
# SSH into EC2 and stress CPU
ssh -i your-key.pem ec2-user@instance-ip

# Inside EC2:
stress-ng --cpu 1 --timeout 300s

# Monitor:
# 1. CloudWatch alarm changes to ALARM
# 2. Lambda is invoked
# 3. Email arrives in inbox
# 4. DevOps Agent starts investigation
```

---

## Troubleshooting

### Email Not Sent

**Check CloudWatch logs:**
```bash
aws logs tail /aws/lambda/DevOpsAgentInvestigationTrigger --follow
```

**Common issues:**
- `SENDER_EMAIL` not verified in SES
- `RECIPIENT_EMAILS` in sandbox mode (need to verify)
- IAM role missing SES permissions
- Wrong AWS region (must be us-east-1)

### SES Errors

**"MessageRejected"**
```bash
# Email not verified
aws ses list-verified-email-addresses
aws ses verify-email-identity --email-address YOUR_EMAIL
```

**"Sandbox mode"**
```bash
# Request production access in AWS Console
# SES → Account Dashboard → Request sending limit increase
# Usually approved within 24 hours
```

### Investigation Not Starting

**Check:**
- `AGENT_SPACE_ID` is correct
- DevOps Agent role has CloudWatch permissions
- Alarm state is `ALARM` (not `OK`)
- Agent space still exists

---

## Verification Checklist

- [ ] Email verified in SES
- [ ] IAM role has SES permissions
- [ ] `AGENT_SPACE_ID` set correctly
- [ ] `SENDER_EMAIL` and `RECIPIENT_EMAILS` configured
- [ ] Lambda function deployed
- [ ] SNS subscription created
- [ ] CloudWatch alarm configured
- [ ] Test invocation successful
- [ ] Email received in inbox
- [ ] HTML displays correctly
- [ ] Investigation ID clickable

---

## Complete Deployment One-Liner

```bash
#!/bin/bash
set -e

ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
AGENT_SPACE_ID="YOUR_AGENT_SPACE_ID"  # SET THIS!
SENDER_EMAIL="devops-agent@company.com"
RECIPIENT_EMAILS="team@company.com,manager@company.com"

# 1. Verify email
aws ses verify-email-identity --email-address ${SENDER_EMAIL} --region us-east-1

# 2. Update role with SES permissions
cat > combined-policy.json << 'EOF'
{"Version":"2012-10-17","Statement":[{"Sid":"DevOpsAgentAccess","Effect":"Allow","Action":["devopsagent:CreateInvestigation","devopsagent:DescribeInvestigation","devopsagent:ListInvestigations"],"Resource":"*"},{"Sid":"CloudWatchAccess","Effect":"Allow","Action":["cloudwatch:GetMetricStatistics","cloudwatch:ListMetrics","cloudwatch:DescribeAlarms"],"Resource":"*"},{"Sid":"SESAccess","Effect":"Allow","Action":["ses:SendEmail","ses:SendRawEmail"],"Resource":"*"},{"Sid":"SNSPublish","Effect":"Allow","Action":["sns:Publish"],"Resource":"*"},{"Sid":"CloudWatchLogs","Effect":"Allow","Action":["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],"Resource":"arn:aws:logs:*:*:*"}]}
EOF
aws iam put-role-policy --role-name DevOpsAgentInvestigationLambdaRole --policy-name DevOpsAgentCombinedPolicy --policy-document file://combined-policy.json

# 3. Package function
zip lambda_complete_with_ses.zip lambda_complete_with_ses.py

# 4. Update function
aws lambda update-function-code \
  --function-name DevOpsAgentInvestigationTrigger \
  --zip-file fileb://lambda_complete_with_ses.zip \
  --region us-east-1

# 5. Update environment
aws lambda update-function-configuration \
  --function-name DevOpsAgentInvestigationTrigger \
  --environment Variables="{AGENT_SPACE_ID=${AGENT_SPACE_ID},SENDER_EMAIL=${SENDER_EMAIL},RECIPIENT_EMAILS=${RECIPIENT_EMAILS}}" \
  --region us-east-1

# 6. Test
aws lambda invoke \
  --function-name DevOpsAgentInvestigationTrigger \
  --payload file://test-event.json \
  response.json

echo "✅ Deployment complete!"
echo "📧 Check email for test notification"
```

---

## What Happens When Alarm Triggers

1. **CloudWatch detects breach** → Publishes to SNS
2. **SNS delivers message** → Invokes Lambda (<1s)
3. **Lambda processes**:
   - Parses alarm metadata
   - Calls DevOps Agent API (investigation starts)
   - Sends email via SES
   - Posts to Slack (if configured)
4. **Email arrives** → Contains alarm details + investigation ID
5. **DevOps Agent analyzes**:
   - CloudWatch metrics (24 hours)
   - CloudTrail events (90 days)
   - Application logs
   - Recent deployments
6. **Results displayed** in web app + email updates

---

## Next Steps

1. ✅ Deploy the complete function
2. ✅ Test with sample event
3. ✅ Verify email received
4. ✅ Create test alarm (stress CPU)
5. ✅ Monitor real investigation
6. ✅ Add to production alarms
7. ✅ Monitor metrics (SES bounce rate, etc.)

---
