# Quick CLI Reference: DevOps Agent Lambda Setup

## One-Liner Deployment (After Prerequisites)

```bash
#!/bin/bash
set -e

# Configuration
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
AGENT_SPACE_ID="YOUR_AGENT_SPACE_ID"  # Replace with your Agent Space ID
AWS_REGION="us-east-1"

echo "🚀 Starting DevOps Agent Investigation Lambda deployment..."
echo "Account ID: $ACCOUNT_ID"
echo "Region: $AWS_REGION"

# 1. Create IAM Role
echo "1️⃣  Creating IAM role..."
cat > trust-policy.json << 'EOF'
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {"Service": "lambda.amazonaws.com"},
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF

ROLE_ARN=$(aws iam create-role \
  --role-name DevOpsAgentInvestigationLambdaRole \
  --assume-role-policy-document file://trust-policy.json \
  --query 'Role.Arn' --output text 2>/dev/null || \
  aws iam get-role \
  --role-name DevOpsAgentInvestigationLambdaRole \
  --query 'Role.Arn' --output text)

echo "✅ Role created/found: $ROLE_ARN"

# 2. Attach IAM Policy
echo "2️⃣  Attaching IAM policy..."
cat > lambda-policy.json << 'EOF'
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "DevOpsAgentAccess",
      "Effect": "Allow",
      "Action": ["devopsagent:CreateInvestigation", "devopsagent:DescribeInvestigation", "devopsagent:ListInvestigations"],
      "Resource": "*"
    },
    {
      "Sid": "CloudWatchAccess",
      "Effect": "Allow",
      "Action": ["cloudwatch:GetMetricStatistics", "cloudwatch:ListMetrics", "cloudwatch:DescribeAlarms"],
      "Resource": "*"
    },
    {
      "Sid": "SNSPublish",
      "Effect": "Allow",
      "Action": ["sns:Publish"],
      "Resource": "*"
    },
    {
      "Sid": "CloudWatchLogs",
      "Effect": "Allow",
      "Action": ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"],
      "Resource": "arn:aws:logs:*:*:*"
    }
  ]
}
EOF

aws iam put-role-policy \
  --role-name DevOpsAgentInvestigationLambdaRole \
  --policy-name DevOpsAgentInvestigationPolicy \
  --policy-document file://lambda-policy.json

echo "✅ Policy attached"

# Wait for role propagation (IAM is eventually consistent)
sleep 10

# 3. Create SNS Topic
echo "3️⃣  Creating SNS topic..."
SNS_TOPIC_ARN=$(aws sns create-topic \
  --name devops-agent-alarm-triggers \
  --region $AWS_REGION \
  --query 'TopicArn' --output text)

echo "✅ SNS topic created: $SNS_TOPIC_ARN"

# 4. Package Lambda function
echo "4️⃣  Packaging Lambda function..."
zip -q lambda_deployment.zip lambda_trigger.py
echo "✅ Package created: lambda_deployment.zip"

# 5. Deploy Lambda
echo "5️⃣  Deploying Lambda function..."
LAMBDA_ARN=$(aws lambda create-function \
  --function-name DevOpsAgentInvestigationTrigger \
  --runtime python3.11 \
  --role $ROLE_ARN \
  --handler lambda_trigger.lambda_handler \
  --zip-file fileb://lambda_deployment.zip \
  --timeout 60 \
  --memory-size 256 \
  --region $AWS_REGION \
  --environment "Variables={AGENT_SPACE_ID=$AGENT_SPACE_ID,SLACK_CHANNEL=#devops-investigations,SNS_TOPIC_ARN=$SNS_TOPIC_ARN}" \
  --query 'FunctionArn' --output text 2>/dev/null || \
  aws lambda get-function \
  --function-name DevOpsAgentInvestigationTrigger \
  --region $AWS_REGION \
  --query 'Configuration.FunctionArn' --output text)

echo "✅ Lambda deployed: $LAMBDA_ARN"

# 6. Grant Lambda permission for SNS
echo "6️⃣  Granting Lambda SNS invoke permission..."
aws lambda add-permission \
  --function-name DevOpsAgentInvestigationTrigger \
  --statement-id AllowSNSInvoke \
  --action lambda:InvokeFunction \
  --principal sns.amazonaws.com \
  --source-arn $SNS_TOPIC_ARN \
  --region $AWS_REGION 2>/dev/null || echo "   (Permission may already exist)"

echo "✅ Permission granted"

# 7. Subscribe Lambda to SNS
echo "7️⃣  Subscribing Lambda to SNS topic..."
SUBSCRIPTION_ARN=$(aws sns subscribe \
  --topic-arn $SNS_TOPIC_ARN \
  --protocol lambda \
  --notification-endpoint $LAMBDA_ARN \
  --region $AWS_REGION \
  --query 'SubscriptionArn' --output text)

echo "✅ Subscription created: $SUBSCRIPTION_ARN"

# 8. Summary
echo ""
echo "╔════════════════════════════════════════════════════════╗"
echo "║        ✅ Deployment Complete!                         ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""
echo "📋 Important Information:"
echo ""
echo "   Lambda Function ARN:"
echo "   $LAMBDA_ARN"
echo ""
echo "   SNS Topic ARN:"
echo "   $SNS_TOPIC_ARN"
echo ""
echo "   Agent Space ID:"
echo "   $AGENT_SPACE_ID"
echo ""
echo "🔧 Next Steps:"
echo ""
echo "   1. Update your CloudWatch alarms to publish to SNS topic:"
echo "      aws cloudwatch put-metric-alarm ... --alarm-actions $SNS_TOPIC_ARN"
echo ""
echo "   2. Test the integration with:"
echo "      aws lambda invoke --function-name DevOpsAgentInvestigationTrigger --payload file://test-event.json response.json"
echo ""
echo "   3. Monitor Lambda logs with:"
echo "      aws logs tail /aws/lambda/DevOpsAgentInvestigationTrigger --follow"
echo ""
echo "   4. Verify DevOps Agent investigation in web app:"
echo "      Incident Response → Find '[AUTO]' investigations"
echo ""
```

Save as: `deploy.sh` and run:
```bash
chmod +x deploy.sh
./deploy.sh
```

---

## Common CLI Commands

### Check Lambda Function Status
```bash
aws lambda get-function \
  --function-name DevOpsAgentInvestigationTrigger \
  --region us-east-1
```

### View Lambda Logs (Last 100 lines)
```bash
aws logs tail /aws/lambda/DevOpsAgentInvestigationTrigger \
  --max-items 100 \
  --region us-east-1
```

### View Lambda Logs (Live Stream)
```bash
aws logs tail /aws/lambda/DevOpsAgentInvestigationTrigger \
  --follow \
  --region us-east-1
```

### Test Lambda with SNS Event
```bash
aws lambda invoke \
  --function-name DevOpsAgentInvestigationTrigger \
  --payload file://test-event.json \
  --region us-east-1 \
  response.json

cat response.json
```

### Update Lambda Environment Variables
```bash
aws lambda update-function-configuration \
  --function-name DevOpsAgentInvestigationTrigger \
  --environment Variables="{
    AGENT_SPACE_ID=YOUR_NEW_AGENT_SPACE_ID,
    SLACK_CHANNEL=#new-channel,
    SNS_TOPIC_ARN=arn:aws:sns:us-east-1:ACCOUNT_ID:new-topic
  }" \
  --region us-east-1
```

### Update Lambda Code
```bash
# After modifying lambda_trigger.py
zip -q lambda_deployment.zip lambda_trigger.py

aws lambda update-function-code \
  --function-name DevOpsAgentInvestigationTrigger \
  --zip-file fileb://lambda_deployment.zip \
  --region us-east-1
```

### Add CloudWatch Alarm Action (SNS)
```bash
aws cloudwatch put-metric-alarm \
  --alarm-name MyAlarm \
  --alarm-description "Test alarm" \
  --metric-name CPUUtilization \
  --namespace AWS/EC2 \
  --statistic Average \
  --period 300 \
  --threshold 80 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2 \
  --alarm-actions arn:aws:sns:us-east-1:ACCOUNT_ID:devops-agent-alarm-triggers \
  --region us-east-1
```

### List All Alarms Pointing to SNS Topic
```bash
aws cloudwatch describe-alarms \
  --region us-east-1 \
  --query 'MetricAlarms[?AlarmActions[]].{Name:AlarmName,Actions:AlarmActions}' \
  --output table
```

### Get SNS Topic Subscriptions
```bash
SNS_TOPIC_ARN="arn:aws:sns:us-east-1:ACCOUNT_ID:devops-agent-alarm-triggers"

aws sns list-subscriptions-by-topic \
  --topic-arn $SNS_TOPIC_ARN \
  --region us-east-1
```

### Publish Test Message to SNS
```bash
SNS_TOPIC_ARN="arn:aws:sns:us-east-1:ACCOUNT_ID:devops-agent-alarm-triggers"

aws sns publish \
  --topic-arn $SNS_TOPIC_ARN \
  --message file://test-event.json \
  --region us-east-1
```

### Delete All Resources
```bash
# Delete Lambda function
aws lambda delete-function \
  --function-name DevOpsAgentInvestigationTrigger \
  --region us-east-1

# Delete SNS topic
aws sns delete-topic \
  --topic-arn arn:aws:sns:us-east-1:ACCOUNT_ID:devops-agent-alarm-triggers \
  --region us-east-1

# Delete IAM policy
aws iam delete-role-policy \
  --role-name DevOpsAgentInvestigationLambdaRole \
  --policy-name DevOpsAgentInvestigationPolicy

# Delete IAM role
aws iam delete-role \
  --role-name DevOpsAgentInvestigationLambdaRole
```

---

## Troubleshooting Commands

### Check IAM Role Trust Relationship
```bash
aws iam get-role \
  --role-name DevOpsAgentInvestigationLambdaRole \
  --query 'Role.AssumeRolePolicyDocument'
```

### Check IAM Role Permissions
```bash
aws iam get-role-policy \
  --role-name DevOpsAgentInvestigationLambdaRole \
  --policy-name DevOpsAgentInvestigationPolicy
```

### Get Lambda Function Configuration
```bash
aws lambda get-function-configuration \
  --function-name DevOpsAgentInvestigationTrigger \
  --region us-east-1
```

### Check CloudWatch Log Group
```bash
aws logs describe-log-groups \
  --log-group-name-prefix /aws/lambda/DevOpsAgentInvestigationTrigger \
  --region us-east-1
```

### Monitor Lambda Metrics
```bash
aws cloudwatch get-metric-statistics \
  --namespace AWS/Lambda \
  --metric-name Duration \
  --dimensions Name=FunctionName,Value=DevOpsAgentInvestigationTrigger \
  --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 300 \
  --statistics Average,Maximum \
  --region us-east-1
```

---

## Shell Aliases (Add to ~/.bashrc or ~/.zshrc)

```bash
# DevOps Agent Lambda shortcuts
alias devops-logs='aws logs tail /aws/lambda/DevOpsAgentInvestigationTrigger --follow'
alias devops-test='aws lambda invoke --function-name DevOpsAgentInvestigationTrigger --payload file://test-event.json response.json && cat response.json'
alias devops-config='aws lambda get-function-configuration --function-name DevOpsAgentInvestigationTrigger --region us-east-1'
alias devops-redeploy='zip -q lambda_deployment.zip lambda_trigger.py && aws lambda update-function-code --function-name DevOpsAgentInvestigationTrigger --zip-file fileb://lambda_deployment.zip --region us-east-1'
```

Source the file:
```bash
source ~/.bashrc  # or ~/.zshrc
```

---

## Expected CLI Output Examples

### Successful Lambda Deployment
```
✅ Role created/found: arn:aws:iam::123456789012:role/DevOpsAgentInvestigationLambdaRole
✅ Policy attached
✅ SNS topic created: arn:aws:sns:us-east-1:123456789012:devops-agent-alarm-triggers
✅ Package created: lambda_deployment.zip
✅ Lambda deployed: arn:aws:lambda:us-east-1:123456789012:function:DevOpsAgentInvestigationTrigger
✅ Permission granted
✅ Subscription created: arn:aws:sns:us-east-1:123456789012:devops-agent-alarm-triggers:subscription-id
```

### Successful Test Invoke
```json
{
    "statusCode": 200,
    "body": "{\"message\": \"Investigation started successfully\", \"investigationId\": \"inv-abc123def456\", \"alarmName\": \"Test-CPU-Utilization-Alarm\", \"timestamp\": \"2026-01-28T17:35:42.123456\"}"
}
```

---
