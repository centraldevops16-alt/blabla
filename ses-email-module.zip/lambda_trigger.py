"""
AWS DevOps Agent Investigation Trigger Lambda
Automatically starts investigations when CloudWatch alarms fire

Dependencies: boto3 (pre-installed in Lambda)
"""

import json
import boto3
import os
from datetime import datetime
from typing import Dict, Any

# Initialize AWS clients
devopsagent_client = boto3.client('devopsagent', region_name='us-east-1')
cloudwatch_client = boto3.client('cloudwatch', region_name='us-east-1')
sns_client = boto3.client('sns')
logs_client = boto3.client('logs')

# Environment variables (set these in Lambda configuration)
AGENT_SPACE_ID = os.environ.get('AGENT_SPACE_ID')
SLACK_CHANNEL = os.environ.get('SLACK_CHANNEL', '#devops-investigations')
SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN')


def parse_cloudwatch_alarm(sns_message: Dict[str, Any]) -> Dict[str, Any]:
    """
    Parse SNS message from CloudWatch alarm
    
    Args:
        sns_message: SNS message body containing alarm details
        
    Returns:
        Dictionary with alarm details
    """
    try:
        alarm_data = {
            'alarm_name': sns_message.get('AlarmName', 'Unknown'),
            'alarm_description': sns_message.get('AlarmDescription', ''),
            'state': sns_message.get('StateValue', 'ALARM'),
            'state_reason': sns_message.get('StateReason', ''),
            'alarm_arn': sns_message.get('AlarmArn', ''),
            'account_id': sns_message.get('AWSAccountId', ''),
            'region': sns_message.get('Region', 'us-east-1'),
            'trigger': sns_message.get('Trigger', {}),
            'timestamp': sns_message.get('StateChangeTime', datetime.utcnow().isoformat()),
        }
        return alarm_data
    except Exception as e:
        print(f"Error parsing CloudWatch alarm: {str(e)}")
        raise


def create_investigation_title(alarm_data: Dict[str, Any]) -> str:
    """
    Create a descriptive investigation title
    """
    timestamp = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
    return f"[AUTO] {alarm_data['alarm_name']} - {timestamp}"


def create_investigation_description(alarm_data: Dict[str, Any]) -> str:
    """
    Create detailed investigation description
    """
    trigger_info = alarm_data.get('trigger', {})
    
    description = f"""
Automatic Investigation Triggered by CloudWatch Alarm

**Alarm Details:**
- Name: {alarm_data['alarm_name']}
- Status: {alarm_data['state']}
- ARN: {alarm_data['alarm_arn']}
- Region: {alarm_data['region']}
- Account: {alarm_data['account_id']}

**State Reason:**
{alarm_data['state_reason']}

**Alarm Description:**
{alarm_data['alarm_description']}

**Metric Information:**
- Namespace: {trigger_info.get('Namespace', 'N/A')}
- MetricName: {trigger_info.get('MetricName', 'N/A')}
- Dimensions: {json.dumps(trigger_info.get('Dimensions', []), indent=2)}
- Statistic: {trigger_info.get('Statistic', 'N/A')}
- Period: {trigger_info.get('Period', 'N/A')} seconds
- Threshold: {trigger_info.get('Threshold', 'N/A')}
- ComparisonOperator: {trigger_info.get('ComparisonOperator', 'N/A')}

**Investigation Focus Areas:**
1. Recent metric anomalies
2. Recent deployments or configuration changes
3. Related resource changes via CloudTrail
4. Log anomalies during the alarm period
5. Service dependency chain analysis
"""
    return description.strip()


def start_investigation(alarm_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Start investigation via AWS DevOps Agent API
    
    Args:
        alarm_data: Parsed alarm information
        
    Returns:
        Investigation response from DevOps Agent
    """
    try:
        investigation_title = create_investigation_title(alarm_data)
        investigation_description = create_investigation_description(alarm_data)
        
        print(f"Starting investigation: {investigation_title}")
        print(f"Agent Space ID: {AGENT_SPACE_ID}")
        
        # Call DevOps Agent API to create investigation
        response = devopsagent_client.create_investigation(
            agentSpaceId=AGENT_SPACE_ID,
            investigationTitle=investigation_title,
            investigationDescription=investigation_description,
            investigationSource={
                'sourceType': 'ALARM',
                'sourceArn': alarm_data['alarm_arn']
            },
            includeCloudTrailEvents=True,
            includeDeploymentData=True,
            includeLogData=True
        )
        
        print(f"Investigation created successfully: {response}")
        return response
        
    except Exception as e:
        error_msg = f"Error starting investigation: {str(e)}"
        print(error_msg)
        raise


def get_alarm_metrics(alarm_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Fetch recent metrics for the triggered alarm
    
    Args:
        alarm_data: Parsed alarm information
        
    Returns:
        Dictionary with metric statistics
    """
    try:
        trigger = alarm_data.get('trigger', {})
        namespace = trigger.get('Namespace', 'AWS/EC2')
        metric_name = trigger.get('MetricName', 'CPUUtilization')
        dimensions = trigger.get('Dimensions', [])
        
        # Convert dimensions to boto3 format
        cloudwatch_dimensions = [
            {'Name': dim.get('name', ''), 'Value': dim.get('value', '')}
            for dim in dimensions if dim.get('name') and dim.get('value')
        ]
        
        # Get last 10 minutes of metric data
        response = cloudwatch_client.get_metric_statistics(
            Namespace=namespace,
            MetricName=metric_name,
            Dimensions=cloudwatch_dimensions,
            StartTime=datetime.utcnow().replace(
                minute=datetime.utcnow().minute - 10
            ),
            EndTime=datetime.utcnow(),
            Period=60,
            Statistics=['Average', 'Maximum', 'Minimum']
        )
        
        return response.get('Datapoints', [])
        
    except Exception as e:
        print(f"Error fetching metrics: {str(e)}")
        return []


def send_slack_notification(alarm_data: Dict[str, Any], investigation_response: Dict[str, Any]) -> None:
    """
    Send Slack notification about investigation start
    (Optional if Slack integration not already configured)
    
    Args:
        alarm_data: Parsed alarm information
        investigation_response: Response from DevOps Agent API
    """
    try:
        if not SNS_TOPIC_ARN:
            print("SNS_TOPIC_ARN not configured, skipping Slack notification")
            return
        
        investigation_id = investigation_response.get('investigationId', 'Unknown')
        
        message = {
            'channel': SLACK_CHANNEL,
            'username': 'AWS DevOps Agent',
            'icon_emoji': ':robot_face:',
            'attachments': [
                {
                    'color': 'danger',
                    'title': f":alarm_clock: CloudWatch Alarm Triggered",
                    'text': f"Investigation automatically started for: {alarm_data['alarm_name']}",
                    'fields': [
                        {
                            'title': 'Alarm Name',
                            'value': alarm_data['alarm_name'],
                            'short': True
                        },
                        {
                            'title': 'Status',
                            'value': alarm_data['state'],
                            'short': True
                        },
                        {
                            'title': 'Region',
                            'value': alarm_data['region'],
                            'short': True
                        },
                        {
                            'title': 'Investigation ID',
                            'value': investigation_id,
                            'short': True
                        },
                        {
                            'title': 'State Reason',
                            'value': alarm_data['state_reason'],
                            'short': False
                        },
                        {
                            'title': 'Alarm ARN',
                            'value': alarm_data['alarm_arn'],
                            'short': False
                        }
                    ],
                    'footer': 'AWS DevOps Agent',
                    'ts': int(datetime.utcnow().timestamp())
                }
            ]
        }
        
        # Publish to SNS (which can trigger Slack webhook)
        sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=json.dumps(message),
            Subject=f"DevOps Investigation Started: {alarm_data['alarm_name']}"
        )
        
        print("Slack notification sent successfully")
        
    except Exception as e:
        print(f"Error sending Slack notification: {str(e)}")
        # Don't raise - this is non-critical


def log_investigation_details(alarm_data: Dict[str, Any], investigation_response: Dict[str, Any]) -> None:
    """
    Log investigation details to CloudWatch Logs
    
    Args:
        alarm_data: Parsed alarm information
        investigation_response: Response from DevOps Agent API
    """
    try:
        log_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'alarm_name': alarm_data['alarm_name'],
            'investigation_id': investigation_response.get('investigationId'),
            'alarm_arn': alarm_data['alarm_arn'],
            'account_id': alarm_data['account_id'],
            'region': alarm_data['region'],
            'status': 'INVESTIGATION_STARTED'
        }
        
        print(f"Investigation logged: {json.dumps(log_entry)}")
        
    except Exception as e:
        print(f"Error logging investigation: {str(e)}")


def lambda_handler(event, context):
    """
    Main Lambda handler
    
    Event structure (from SNS):
    {
        "Records": [
            {
                "Sns": {
                    "Message": "<CloudWatch alarm message in JSON>"
                }
            }
        ]
    }
    """
    
    print(f"Event received: {json.dumps(event, indent=2)}")
    print(f"Agent Space ID: {AGENT_SPACE_ID}")
    
    try:
        # Validate Agent Space ID
        if not AGENT_SPACE_ID:
            error_msg = "AGENT_SPACE_ID environment variable not set"
            print(error_msg)
            return {
                'statusCode': 400,
                'body': json.dumps({'error': error_msg})
            }
        
        # Extract SNS message
        if 'Records' not in event or len(event['Records']) == 0:
            error_msg = "No SNS records found in event"
            print(error_msg)
            return {
                'statusCode': 400,
                'body': json.dumps({'error': error_msg})
            }
        
        sns_message_str = event['Records'][0]['Sns']['Message']
        sns_message = json.loads(sns_message_str)
        
        print(f"SNS Message: {json.dumps(sns_message, indent=2)}")
        
        # Parse alarm data
        alarm_data = parse_cloudwatch_alarm(sns_message)
        print(f"Parsed alarm data: {json.dumps(alarm_data, indent=2)}")
        
        # Only trigger investigation for ALARM state (not OK or INSUFFICIENT_DATA)
        if alarm_data['state'] != 'ALARM':
            print(f"Alarm state is {alarm_data['state']}, skipping investigation")
            return {
                'statusCode': 200,
                'body': json.dumps({'message': f"Alarm state {alarm_data['state']}, no investigation triggered"})
            }
        
        # Fetch recent metrics (optional but helpful context)
        metrics = get_alarm_metrics(alarm_data)
        print(f"Recent metrics: {json.dumps(metrics, default=str)}")
        
        # Start investigation
        investigation_response = start_investigation(alarm_data)
        
        # Log investigation
        log_investigation_details(alarm_data, investigation_response)
        
        # Send Slack notification (optional)
        send_slack_notification(alarm_data, investigation_response)
        
        # Return success
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Investigation started successfully',
                'investigationId': investigation_response.get('investigationId'),
                'alarmName': alarm_data['alarm_name'],
                'timestamp': datetime.utcnow().isoformat()
            })
        }
        
    except Exception as e:
        error_msg = f"Lambda execution failed: {str(e)}"
        print(error_msg)
        
        return {
            'statusCode': 500,
            'body': json.dumps({'error': error_msg})
        }
